# Alpha Live Translator — Current Project Guide

- **Current accepted version:** V3.3.5.5.8.5.23.2 — Evidence Protection & Audit Coverage Improvement
- **Main entry:** `main.py`
- **Current validation:** `validate_accuracy_85232.py`
- **Current smoke test:** `runtime_smoke_start_stop_85232.py`
- **Current benchmark scoring:** `score_latest_accuracy.py`
- **Current reference checker:** `reference_transcript_quality_check.py`
- **Package latest run:** `package_latest_troubleshooting_run.py`

Runtime and evidence artifacts live under `troubleshooting/` (especially `troubleshooting/latest/`).

Old root-level validation scripts, smoke tests, README notes, and outputs were moved to `_cleanup_archive/` (see `CLEANUP_MANIFEST.txt` inside the latest archive folder).
