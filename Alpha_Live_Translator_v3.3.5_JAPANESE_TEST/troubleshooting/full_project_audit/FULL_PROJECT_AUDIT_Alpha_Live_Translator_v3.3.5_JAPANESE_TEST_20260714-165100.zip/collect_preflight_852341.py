"""Preflight evidence collection before 8.5.23.4.1 changes."""

from __future__ import annotations

import hashlib
import json
import shutil
import time
from pathlib import Path

from alpha.constants import APP_VERSION


def _sha256(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    root = Path("troubleshooting")
    preflight = root / "preflight_852341"
    preflight.mkdir(parents=True, exist_ok=True)
    print("PREFLIGHT_852341_COLLECTION_STARTED")
    warnings: list[str] = []

    files: list[tuple[Path, str]] = [
        (root / "latest" / "latest_accuracy_evidence_index.json", "latest_accuracy_evidence_index.json"),
        (root / "latest" / "latest_live_alpha_output.txt", "latest_live_alpha_output.txt"),
        (root / "accuracy_benchmark" / "latest_reports" / "LATEST_REPORT_SET_INDEX.json", "LATEST_REPORT_SET_INDEX.json"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_accuracy_score_report.json", "latest_accuracy_score_report.json"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_reference_quality_report.json", "latest_reference_quality_report.json"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_alignment_report.json", "latest_alignment_report.json"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_alignment_report.txt", "latest_alignment_report.txt"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_boundary_error_report.json", "latest_boundary_error_report.json"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_business_term_risk_report.json", "latest_business_term_risk_report.json"),
        (root / "accuracy_benchmark" / "latest_reports" / "latest_glossary_candidates.json", "latest_glossary_candidates.json"),
        (root / "Cursor final report.txt", "Cursor_final_report.txt"),
        (root / "validation" / "validate_accuracy_85234_output.txt", "validate_accuracy_85234_output.txt"),
    ]
    for smoke in sorted((root / "smoke_tests").glob("*85234*")) if (root / "smoke_tests").exists() else []:
        files.append((smoke, f"smoke_{smoke.name}"))

    runs = sorted(
        [p for p in (root / "runs").iterdir() if p.is_dir() and p.name != "_pending"],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    ) if (root / "runs").exists() else []
    upload_zip = ""
    if runs:
        up = runs[0] / "upload_package"
        zips = sorted(up.glob("UPLOAD_PACKAGE_*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        if zips:
            upload_zip = str(zips[0])
            files.append((zips[0], "latest_upload_package.zip"))

    idx: dict = {}
    idx_path = root / "latest" / "latest_accuracy_evidence_index.json"
    if idx_path.exists():
        idx = json.loads(idx_path.read_text(encoding="utf-8"))

    critical = {"latest_accuracy_evidence_index.json", "latest_live_alpha_output.txt", "latest_accuracy_score_report.json"}
    for src, dst in files:
        if src.exists():
            shutil.copy2(src, preflight / dst)
            print(f"PREFLIGHT_852341_FILE_COLLECTED: {src}")
        else:
            print(f"PREFLIGHT_852341_FILE_MISSING: {src}")
            if dst in critical:
                warnings.append(f"critical_missing:{dst}")

    alpha_path = root / "latest" / "latest_live_alpha_output.txt"
    ref_path = Path("troubleshooting/accuracy_benchmark/reference_transcripts/test01.txt")
    score_path = root / "accuracy_benchmark" / "latest_reports" / "latest_accuracy_score_report.json"
    align_path = root / "accuracy_benchmark" / "latest_reports" / "latest_alignment_report.json"
    boundary_path = root / "accuracy_benchmark" / "latest_reports" / "latest_boundary_error_report.json"

    manifest = {
        "collected_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "app_version_before_change": "3.3.5.5.8.5.23.4",
        "latest_run_id": idx.get("run_id", ""),
        "latest_alpha_path": str(alpha_path),
        "latest_alpha_size_bytes": alpha_path.stat().st_size if alpha_path.exists() else 0,
        "latest_alpha_sha256": _sha256(alpha_path),
        "latest_reference_path": str(ref_path),
        "latest_reference_sha256": _sha256(ref_path),
        "latest_score_report_path": str(score_path) if score_path.exists() else "",
        "latest_alignment_report_path": str(align_path) if align_path.exists() else "",
        "latest_boundary_report_path": str(boundary_path) if boundary_path.exists() else "",
        "latest_upload_package_path_if_known": upload_zip,
        "warnings": warnings,
    }
    (preflight / "PREFLIGHT_852341_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (preflight / "PREFLIGHT_852341_SUMMARY.txt").write_text(
        "\n".join(
            [
                "PREFLIGHT 852341 SUMMARY",
                f"collected_at={manifest['collected_at']}",
                f"app_version_before_change={manifest['app_version_before_change']}",
                f"latest_run_id={manifest['latest_run_id']}",
                f"latest_alpha_sha256={manifest['latest_alpha_sha256'][:16]}...",
                f"latest_upload_package={upload_zip or 'none'}",
                f"warnings={warnings}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print("PREFLIGHT_852341_MANIFEST_WRITTEN")
    print("PREFLIGHT_852341_COLLECTION_COMPLETED")
    return 1 if any("critical_missing" in w for w in warnings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
