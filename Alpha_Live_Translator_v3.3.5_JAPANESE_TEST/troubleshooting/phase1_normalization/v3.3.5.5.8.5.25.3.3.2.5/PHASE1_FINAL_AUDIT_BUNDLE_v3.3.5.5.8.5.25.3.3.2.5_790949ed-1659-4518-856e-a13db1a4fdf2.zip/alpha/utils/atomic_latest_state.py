"""Atomic repair of latest_* Alpha Final aliases from PROJECT_STATE authority."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from alpha.utils.phase1_build_identity import (
    EXPECTED_FINAL_SHA256,
    sha256_bytes,
    sha256_file,
    utc_now_iso,
    write_json_report,
)

ALIAS_RELS = (
    "troubleshooting/Alpha.txt",
    "troubleshooting/latest_alpha_output.txt",
    "troubleshooting/latest/latest_alpha_output.txt",
    "troubleshooting/latest/latest_live_alpha_output.txt",
)


class AtomicLatestStateError(RuntimeError):
    pass


def _atomic_write_bytes(dest: Path, data: bytes) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=dest.name + ".", suffix=".tmp", dir=str(dest.parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(str(tmp_path), str(dest))
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def load_project_state(project_root: Path) -> dict[str, Any]:
    path = project_root / "troubleshooting" / "PROJECT_STATE.json"
    if not path.exists():
        raise AtomicLatestStateError(f"PROJECT_STATE_missing:{path}")
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_authoritative_final(project_root: Path, state: dict[str, Any] | None = None) -> Path:
    state = state or load_project_state(project_root)
    rel = state.get("authoritative_final_path") or state.get("paths", {}).get(
        "authoritative_final"
    )
    if not rel:
        raise AtomicLatestStateError("authoritative_final_path_missing_in_PROJECT_STATE")
    path = Path(rel)
    if not path.is_absolute():
        path = project_root / path
    path = path.resolve()
    if not path.exists():
        raise AtomicLatestStateError(f"authoritative_final_missing:{path}")
    return path


def repair_latest_aliases(
    project_root: Path,
    *,
    identity: dict[str, Any] | None = None,
    expected_sha256: str = EXPECTED_FINAL_SHA256,
) -> dict[str, Any]:
    """Copy authoritative Final bytes to latest aliases atomically. Never rewrite Final."""
    project_root = project_root.resolve()
    state = load_project_state(project_root)
    final_path = resolve_authoritative_final(project_root, state)
    final_bytes = final_path.read_bytes()
    final_sha = sha256_bytes(final_bytes)
    if final_sha != expected_sha256:
        raise AtomicLatestStateError(
            f"authoritative_final_sha_mismatch:expected={expected_sha256}:got={final_sha}"
        )

    repaired: list[dict[str, Any]] = []
    for rel in ALIAS_RELS:
        dest = project_root / rel
        before = sha256_file(dest) if dest.exists() else None
        _atomic_write_bytes(dest, final_bytes)
        after = sha256_file(dest)
        if after != expected_sha256:
            raise AtomicLatestStateError(f"alias_sha_mismatch:{rel}:{after}")
        repaired.append(
            {
                "path": rel.replace("\\", "/"),
                "sha256_before": before,
                "sha256_after": after,
                "rewritten": before != after,
            }
        )

    latest_state = {
        "generated_at": utc_now_iso(),
        "authoritative_final": str(final_path).replace("\\", "/"),
        "authoritative_final_sha256": final_sha,
        "expected_final_sha256": expected_sha256,
        "aliases": repaired,
        "all_aliases_match_expected": all(r["sha256_after"] == expected_sha256 for r in repaired),
        "authoritative_final_rewritten": False,
    }
    latest_state_path = project_root / "troubleshooting" / "latest" / "LATEST_STATE.json"
    write_json_report(latest_state_path, latest_state, identity=identity)

    reports_payload = dict(latest_state)
    if identity is not None:
        write_json_report(
            Path(identity["reports_dir"]) / "LATEST_STATE_REPAIR.json",
            reports_payload,
            identity=identity,
        )
    return latest_state
