"""Prepare deterministic reference snapshot for V25.3.2 accuracy benchmark."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import time
from pathlib import Path

from alpha.constants import APP_VERSION, DETERMINISTIC_REFERENCE_SNAPSHOT_ENABLED
from reference_transcript_quality_check import check_prepared_reference_snapshot_quality

NORMALIZATION_VERSION = "v25.3.2_nfkc_strip_speaker"
PREPARED_DIR = Path("troubleshooting/accuracy_benchmark/prepared/v3.3.5.5.8.5.25.3.2")


def normalize_reference(text: str) -> str:
    import unicodedata

    lines: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^\[Speaker \d+\]\s*(.+)$", line)
        if m:
            line = m.group(1).strip()
        lines.append(unicodedata.normalize("NFC", line))
    return "\n".join(lines) + ("\n" if lines else "")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    if not DETERMINISTIC_REFERENCE_SNAPSHOT_ENABLED:
        print("DETERMINISTIC_REFERENCE_SNAPSHOT_ENABLED is false")
        return 1
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", required=True)
    args = parser.parse_args()
    source = Path(args.reference)
    if not source.exists() or source.stat().st_size <= 0:
        print(f"Reference missing or empty: {source}")
        return 1

    PREPARED_DIR.mkdir(parents=True, exist_ok=True)
    snapshot_path = PREPARED_DIR / "reference.txt"
    normalized = normalize_reference(source.read_text(encoding="utf-8"))
    snapshot_path.write_text(normalized, encoding="utf-8")

    quality = check_prepared_reference_snapshot_quality(normalized, reference_path=str(source))
    verdict = str(quality.get("verdict", "invalid_for_cer"))
    valid = bool(quality.get("valid_for_cer"))

    ref_snapshot = {
        "app_version": APP_VERSION,
        "source_path": str(source),
        "snapshot_path": str(snapshot_path),
        "source_sha256": sha256_file(source),
        "snapshot_sha256": sha256_file(snapshot_path),
        "normalization_version": NORMALIZATION_VERSION,
        "reference_quality_verdict": verdict,
        "valid_for_cer": valid,
        "failure_reasons": list(quality.get("failure_reasons") or []),
        "prepared_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "created_by": "validation",
    }
    (PREPARED_DIR / "reference_snapshot.json").write_text(
        json.dumps(ref_snapshot, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (PREPARED_DIR / "reference_quality_report.json").write_text(
        json.dumps(quality, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Prepared reference: {snapshot_path}")
    print(f"valid_for_cer={valid}")
    return 0 if valid else 1


if __name__ == "__main__":
    raise SystemExit(main())
