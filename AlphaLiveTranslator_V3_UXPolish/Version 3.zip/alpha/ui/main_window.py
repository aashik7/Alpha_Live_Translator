"""
Alpha Live Translator — main window (V3 UX polish).
Nova-3 STT, dual audio capture (WASAPI + microphone), speaker diarization,
and optimized multilingual support (EN / JA / ZH / RU).
"""

import math
import os
import queue
import re
import threading
import time

import customtkinter as ctk
import numpy as np
import tkinter as tk
from PIL import Image
from tkinter import Menu, messagebox

from alpha.audio.microphone import MicrophoneCaptureMixin
from alpha.audio.processing import pcm_to_mono_16k_np
from alpha.audio.wasapi import WasapiCaptureMixin
from alpha.config import (
    ASSETS_DIR,
    DEEPGRAM_API_KEY,
    DEEPGRAM_ENDPOINTING_MS,
    DEEPGRAM_SAMPLE_RATE,
    HEALTH_MONITOR_INTERVAL_MS,
    LANGUAGE_MAP,
    MAX_AUDIO_QUEUE_SIZE,
    MIC_NOISE_GATE_INITIAL_RMS,
    MIC_RMS_ROLLING_WINDOW_S,
    PROJECT_ROOT,
    TRANSCRIPT_MERGE_WINDOW_S,
    WASAPI_FRAMES_PER_BUFFER,
    get_deepgram_key_status,
)
from alpha.constants import (
    APP_CODENAME,
    APP_VERSION,
    COMPACT_BREAKPOINT,
    SOURCE_LANGUAGES,
    TARGET_LANGUAGES,
)
from alpha.core.event_bus import EventBus
from alpha.core.events import EventType
from alpha.core.models import ErrorEvent, StatusEvent, TranscriptEvent, TranslationEvent
from alpha.transcription.deepgram_client import DeepgramClientMixin
from alpha.transcription.duplicate_protection import DuplicateProtectionMixin
from alpha.transcription.speaker_detection import SpeakerDetectionMixin
from alpha.summary.summary_service import SummaryService
from alpha.summary.transcript_store import TranscriptStore
from alpha.ui.theme import (
    COLORS,
    CONTENT_COMPACT_BREAKPOINT,
    DROPDOWN_BORDER_WIDTH,
    DROPDOWN_HEIGHT,
    DROPDOWN_INNER_BORDER_WIDTH,
    DROPDOWN_WIDTH,
    DROPDOWN_WRAPPER_BORDER_WIDTH,
    FONT_FAMILY,
    FONT_FAMILY_FALLBACK,
    FOOTER_BTN_HEIGHT,
    FOOTER_BTN_HEIGHT_COMPACT,
    FOOTER_BTN_WIDTH,
    FOOTER_BTN_WIDTH_COMPACT,
    FOOTER_BTN_WIDTH_SECONDARY,
    FONTS,
    HEADER_CONTROL_HEIGHT,
    LAYOUT_FOOTER_WRAP_BREAKPOINT,
    LAYOUT_HAMBURGER_BREAKPOINT,
    LAYOUT_MEDIUM_BREAKPOINT,
    LAYOUT_MIN_HEIGHT,
    LAYOUT_MIN_WIDTH,
    LAYOUT_STATUS_COMPACT_BREAKPOINT,
    LAYOUT_WIDE_BREAKPOINT,
    MEETING_SUMMARY_BUTTON_TEXT,
    PLACEHOLDER_SUMMARY,
    PLACEHOLDER_TRANSCRIPT,
    PLACEHOLDER_TRANSLATION,
    RADII,
    SECTION_TRANSCRIPT_TITLE,
    SECTION_TRANSLATION_TITLE,
    SMALL_BUTTON_HEIGHT,
    SPACING,
    SUMMARY_BUTTON_WIDTH,
    SUMMARY_CLOSE_ICON,
    SUMMARY_PANEL_TITLE,
    SUMMARY_TITLE,
    TRANSLATION_TITLE_ICON,
    SWAP_BUTTON_SIZE,
    SPEAKER_COLORS,
    EXTENDED_SPEAKER_COLORS,
    TRANSCRIPT_BODY_FONT,
    TRANSLATION_BODY_FONT,
    WAVEFORM_ANIMATION_MS,
    WAVEFORM_BAR_COUNT,
    WAVEFORM_BAR_COUNT_WIDE,
    WAVEFORM_CANVAS_HEIGHT,
    WAVEFORM_CANVAS_WIDTH,
    WAVEFORM_CANVAS_WIDTH_WIDE,
)
from alpha.utils.logging_utils import get_logger, setup_logging
from alpha.utils.queues import put_bounded


MISSING_API_KEY_MSG = (
    "Deepgram API key is missing. Please add DEEPGRAM_API_KEY to your .env file."
)

PLACEHOLDER_API_KEY_MSG = (
    "Deepgram API key is still set to the example placeholder. "
    "Please replace it with your real Deepgram API key in .env."
)

logger = get_logger(__name__)

# Root window grid rows (header / status / content / footer)
ROOT_ROW_HEADER = 0
ROOT_ROW_STATUS = 1
ROOT_ROW_MENU = 1
ROOT_ROW_CONTENT = 2
ROOT_ROW_FOOTER = 3

LANGUAGE_FLAG_LABELS = {
    "English": "English",
    "Japanese": "Japanese",
    "Chinese (Mandarin)": "Chinese (Mandarin)",
    "Russian": "Russian",
}

# Left column vertical split: Live Transcript (upper, larger) / Translation (lower, smaller)
TRANSCRIPT_PANEL_WEIGHT = 65
TRANSLATION_PANEL_WEIGHT = 35


class AlphaApp(
    ctk.CTk,
    WasapiCaptureMixin,
    MicrophoneCaptureMixin,
    DeepgramClientMixin,
    SpeakerDetectionMixin,
    DuplicateProtectionMixin,
):
    """Main application window for Alpha live meeting translation (V4)."""

    def __init__(self):
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("dark-blue")

        super().__init__()

        self._compact_mode = None
        self._header_mode = None
        self._layout_mode = None
        self._menu_visible = False
        self.summary_panel_visible = True
        self.summary_outer = None
        self.summary_card = None
        self.summary_panel_close_btn = None
        self.summary_title_label = None
        self._status_right_cluster = None
        self.summary_key_points_label = None
        self.left_header_cluster = None
        self.right_header_cluster = None
        self.header_lang_frame = None
        self.header_controls = None
        self.brand_block = None
        self.footer_btn_row = None
        self.footer_btn_row2 = None
        self._footer_buttons = []
        self._pane_initialized = False
        self._initial_verse_visible = True
        self.logo_image = None

        self.source_language = ctk.StringVar(value="English")
        self.target_language = ctk.StringVar(value="Japanese")
        self.source_language.trace_add(
            "write", lambda *_: self.on_language_change("source")
        )
        self.target_language.trace_add(
            "write", lambda *_: self.on_language_change("target")
        )

        self.initial_verse_box = None
        self.translated_verse_box = None
        self.initial_verse_frame = None
        self.translated_verse_frame = None
        self.translated_title_row = None
        self.translated_title_label = None
        self.initial_title_row = None
        self.hide_initial_button = None
        self.show_initial_button = None
        self.always_on_top_switch = None
        self.always_on_top_switch_menu = None
        self.listen_button = None
        self.listen_button_menu = None
        self.footer_stop_button = None
        self.paned = None
        self.left_column = None
        self.right_column = None
        self.status_bar_frame = None
        self.live_pill = None
        self.live_indicator = None
        self.status_text_label = None
        self.timer_label = None
        self.signal_label = None
        self.waveform_canvas = None
        self.summary_body_box = None
        self._listen_start_time = None
        self._timer_job = None
        self._waveform_job = None
        self._waveform_phase = 0
        self._live_pulse_job = None
        self.normal_header_widgets = []

        # Deepgram / audio state
        self.ui_queue = queue.Queue()
        self.transcript_queue = self.ui_queue
        self.is_listening = False
        self._listen_language = LANGUAGE_MAP.get(self.source_language.get(), "en")
        self._audio_q = None
        self.sys_audio_queue = None
        self.mic_audio_queue = None
        self._pyaudio = None
        self._wasapi_stream = None
        self._wasapi_reader_thread = None
        self._mix_thread = None
        self._mic_stream = None
        self._wasapi_channels = 1
        self._wasapi_rate = DEEPGRAM_SAMPLE_RATE
        self._wasapi_frames_per_buffer = WASAPI_FRAMES_PER_BUFFER
        self._dg_ws = None
        self._dg_thread = None
        self._dg_reconnect_lock = threading.Lock()  # CHANGED: reconnect serialization (fix 5)
        self._dg_reconnecting = False  # CHANGED: prevent parallel reconnects (fix 5)
        self._dg_backoff_seconds = 1.0  # CHANGED: exponential backoff start (fix 5)
        self._dg_awaiting_transcript_reset = False  # CHANGED: reset backoff on transcript (fix 5)
        self._dg_replay_buffer = []  # CHANGED: buffered audio for reconnect replay (fix 5)
        self._stop_event = threading.Event()
        self._speaker_lock = threading.Lock()
        self._last_assigned_speaker = 1
        self._last_speaker_change_time = 0.0
        self.last_transcript_hash = set()
        self._transcript_hash_order = []  # CHANGED: ordered hash prune list (fix 8)
        self._last_speaker_utterance = {}  # CHANGED: fuzzy dedup per speaker (fix 8)
        self.last_speaker = None
        self.last_speaker_id = None
        self.current_speaker = None
        self.last_displayed_speaker = None
        self.last_speech_time = 0.0
        self.fallback_speaker = 1
        self._health_monitor_job = None
        self._chunks_sent_count = 0
        self._transcripts_received = 0
        self._health_no_transcript_hint_shown = False
        self.translation_worker = None
        self.translation_enabled = False
        self.translation_error_shown = False
        self.last_translation_speaker = None
        self._recent_displayed_texts = []
        self.transcript_store = TranscriptStore()
        self.summary_service = SummaryService()

        setup_logging()
        self.event_bus = EventBus()
        self._setup_event_subscriptions()

        self.setup_window()
        self.create_solid_background()
        self.create_header_frame()
        self.create_hamburger_menu()
        self.create_status_bar()
        self.create_main_content()
        self.create_footer()
        self._create_context_menu()
        self.bind_resize_event()
        self._bind_keyboard_shortcuts()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.after(100, self._apply_responsive_layout)
        self.after(150, self._set_initial_pane_ratio)
        self._update_translation_title()
        self.after(0, self._initialize_translation)
        self.process_ui_queue()

    # -----------------------------------------------------------------------
    # Window setup
    # -----------------------------------------------------------------------
    def setup_window(self):
        """Configure the main application window."""
        self.title(f"Alpha — Meeting Assistant V{APP_VERSION}")
        self.geometry("900x650")
        self.minsize(LAYOUT_MIN_WIDTH, LAYOUT_MIN_HEIGHT)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(ROOT_ROW_HEADER, weight=0)
        self.grid_rowconfigure(ROOT_ROW_STATUS, weight=0)
        self.grid_rowconfigure(ROOT_ROW_CONTENT, weight=1)
        self.grid_rowconfigure(ROOT_ROW_FOOTER, weight=0)

    def create_solid_background(self):
        """Apply a solid background color to the main window."""
        self.configure(fg_color=COLORS["main_bg"])

    def bind_resize_event(self):
        """Bind window resize events to responsive header logic."""
        self.bind("<Configure>", self.on_window_resize)

    # -----------------------------------------------------------------------
    # UI style helpers (visual consistency only)
    # -----------------------------------------------------------------------
    def _ui_font(self, size, weight="normal"):
        """Return CTkFont using Segoe UI Variable with Segoe UI fallback."""
        for family in (FONT_FAMILY, FONT_FAMILY_FALLBACK, "Segoe UI"):
            try:
                kwargs = {"family": family, "size": size}
                if weight and weight != "normal":
                    kwargs["weight"] = weight
                return ctk.CTkFont(**kwargs)
            except Exception:
                continue
        return ctk.CTkFont(family="Segoe UI", size=size)

    def _language_flag_label(self, plain_language):
        """Return display label with country flag for a plain language name."""
        return LANGUAGE_FLAG_LABELS.get(plain_language, plain_language)

    def _strip_language_flag(self, display_value):
        """Convert a flagged dropdown label back to the plain language name."""
        if not display_value:
            return display_value
        for plain, flagged in LANGUAGE_FLAG_LABELS.items():
            if display_value == flagged:
                return plain
        for plain in LANGUAGE_FLAG_LABELS:
            if plain in display_value:
                return plain
        return display_value.strip()

    def _flagged_language_values(self, plain_values):
        """Build flagged dropdown values from plain language names."""
        return [self._language_flag_label(name) for name in plain_values]

    def _card_config(self):
        """Shared card frame styling."""
        return {
            "fg_color": COLORS["card_bg"],
            "corner_radius": RADII["card"],
            "border_width": 1,
            "border_color": COLORS["border"],
        }

    def _glass_button_config(self, width=None, height=None):
        """Dark glass buttons for header and secondary footer actions."""
        cfg = {
            "height": height or HEADER_CONTROL_HEIGHT,
            "font": self._ui_font(FONTS["button"][1], "bold"),
            "fg_color": COLORS["glass_button_fg"],
            "hover_color": COLORS["glass_button_hover"],
            "text_color": COLORS["glass_button_text"],
            "border_width": 1,
            "border_color": COLORS["glass_button_border"],
            "corner_radius": RADII["glass_button"],
        }
        if width is not None:
            cfg["width"] = width
        return cfg

    def _language_dropdown_wrapper_config(self, width=None):
        """Bordered frame wrapping header language dropdowns for a full outline."""
        cfg = {
            "fg_color": COLORS["glass_button_fg"],
            "border_width": DROPDOWN_WRAPPER_BORDER_WIDTH,
            "border_color": COLORS["glass_button_border"],
            "corner_radius": RADII["glass_button"],
            "height": DROPDOWN_HEIGHT,
        }
        if width is not None:
            cfg["width"] = width
        return cfg

    def _header_glass_combo_config(self, width=None):
        """Header language combo inside wrapper — no border; inset within wrapper outline."""
        cfg = {
            "font": self._ui_font(13),
            "fg_color": COLORS["glass_button_fg"],
            "border_width": DROPDOWN_INNER_BORDER_WIDTH,
            "border_color": COLORS["glass_button_border"],
            "button_color": COLORS["glass_button_fg"],
            "button_hover_color": COLORS["glass_button_hover"],
            "dropdown_fg_color": COLORS["card_bg"],
            "dropdown_hover_color": COLORS["input_bg_hover"],
            "text_color": COLORS["text_primary"],
            "corner_radius": 0,
            "state": "readonly",
        }
        if width is not None:
            cfg["width"] = width
        return cfg

    def _glass_combo_config(self, width=None):
        """Glass-styled language dropdown for the header."""
        return {
            "width": width or DROPDOWN_WIDTH,
            "height": DROPDOWN_HEIGHT,
            "font": self._ui_font(13),
            "fg_color": COLORS["glass_button_fg"],
            "border_color": COLORS["glass_button_border"],
            "border_width": DROPDOWN_BORDER_WIDTH,
            "button_color": COLORS["input_bg"],
            "button_hover_color": COLORS["input_bg_hover"],
            "dropdown_fg_color": COLORS["card_bg"],
            "dropdown_hover_color": COLORS["input_bg_hover"],
            "text_color": COLORS["text_primary"],
            "corner_radius": RADII["combo"],
            "state": "readonly",
        }

    def _glass_icon_button_config(self, size=None, font_size=16):
        """Square glass icon button (swap, close, hamburger)."""
        button_size = size or SWAP_BUTTON_SIZE
        cfg = self._glass_button_config(width=button_size, height=button_size)
        cfg["font"] = self._ui_font(font_size, "bold")
        return cfg

    def _primary_button_config(self, width=None, height=None):
        """Primary action buttons: Start Listening (footer)."""
        cfg = {
            "height": height or FOOTER_BTN_HEIGHT,
            "font": self._ui_font(FONTS["button"][1], "bold"),
            "fg_color": COLORS["accent_blue"],
            "hover_color": COLORS["accent_blue_hover"],
            "text_color": COLORS["text_primary"],
            "corner_radius": RADII["button"],
        }
        if width is not None:
            cfg["width"] = width
        return cfg

    def _secondary_button_config(self, width=None, height=None):
        """Secondary actions: Copy, Export, Clear — dark glass style."""
        cfg = {
            "height": height or FOOTER_BTN_HEIGHT,
            "font": self._ui_font(FONTS["button"][1], "bold"),
            "fg_color": COLORS["glass_button_fg"],
            "hover_color": COLORS["glass_button_hover"],
            "text_color": COLORS["text_primary"],
            "border_width": 1,
            "border_color": COLORS["glass_button_border"],
            "corner_radius": RADII["glass_button"],
        }
        if width is not None:
            cfg["width"] = width
        return cfg

    def _icon_button_config(self, size=None, font_size=16):
        """Legacy icon button config (footer/compact controls)."""
        button_size = size or SWAP_BUTTON_SIZE
        return {
            "width": button_size,
            "height": button_size,
            "font": self._ui_font(font_size, "bold"),
            "fg_color": COLORS["input_bg"],
            "hover_color": COLORS["input_bg_hover"],
            "text_color": COLORS["text_primary"],
            "border_width": 1,
            "border_color": COLORS["border"],
            "corner_radius": RADII["button"],
        }

    def _combo_config(self, width=None):
        """Language dropdown styling (compact menu)."""
        return {
            "width": width or DROPDOWN_WIDTH,
            "height": DROPDOWN_HEIGHT,
            "font": self._ui_font(13),
            "fg_color": COLORS["input_bg"],
            "border_color": COLORS["border"],
            "border_width": DROPDOWN_BORDER_WIDTH,
            "button_color": COLORS["accent_blue"],
            "button_hover_color": COLORS["accent_blue_hover"],
            "dropdown_fg_color": COLORS["card_bg"],
            "dropdown_hover_color": COLORS["input_bg_hover"],
            "text_color": COLORS["text_primary"],
            "corner_radius": RADII["combo"],
            "state": "readonly",
        }

    def _make_language_combo(self, master, plain_values, variable, changed_key):
        """Language dropdown with flag labels; returns (wrapper_frame, combo)."""
        flagged_values = self._flagged_language_values(plain_values)

        def on_select(choice):
            plain = self._strip_language_flag(choice)
            if variable.get() != plain:
                variable.set(plain)
            self.on_language_change(changed_key)

        wrapper = ctk.CTkFrame(
            master=master,
            **self._language_dropdown_wrapper_config(width=DROPDOWN_WIDTH),
        )
        wrapper.pack_propagate(False)

        combo = ctk.CTkComboBox(
            master=wrapper,
            values=flagged_values,
            command=on_select,
            **self._header_glass_combo_config(),
        )
        wrapper.grid_columnconfigure(0, weight=1)
        wrapper.grid_rowconfigure(0, weight=1)
        inset = DROPDOWN_WRAPPER_BORDER_WIDTH
        combo.grid(row=0, column=0, sticky="nsew", padx=inset, pady=inset)
        combo.set(self._language_flag_label(variable.get()))
        return wrapper, combo

    def _sync_language_combo_displays(self):
        """Refresh flagged labels on header language dropdowns."""
        if hasattr(self, "source_combo") and self.source_combo is not None:
            self.source_combo.set(self._language_flag_label(self.source_language.get()))
        if hasattr(self, "target_combo") and self.target_combo is not None:
            self.target_combo.set(self._language_flag_label(self.target_language.get()))

    # -----------------------------------------------------------------------
    # Logo
    # -----------------------------------------------------------------------
    def _load_logo(self):
        """Load logo.png from assets as a 36x36 CTkImage."""
        logo_path = ASSETS_DIR / "logo.png"
        try:
            pil_logo = Image.open(logo_path).resize((36, 36), Image.Resampling.LANCZOS)
            self.logo_image = ctk.CTkImage(
                light_image=pil_logo,
                dark_image=pil_logo,
                size=(36, 36),
            )
        except Exception as exc:
            print(f"Warning: Could not load logo.png ({exc}). Logo will be omitted.")
            self.logo_image = None

    def _make_combo(self, master, values, variable, width=None):
        """Styled language dropdown (compact hamburger menu)."""
        return ctk.CTkComboBox(
            master=master,
            values=values,
            variable=variable,
            **self._combo_config(width=width),
        )

    # -----------------------------------------------------------------------
    # Header
    # -----------------------------------------------------------------------
    def create_header_frame(self):
        """Top header: brand + language controls left, summary actions right."""
        self._load_logo()

        self.header_frame = ctk.CTkFrame(
            master=self,
            fg_color=COLORS["header_bg"],
            corner_radius=0,
            border_width=0,
        )
        self.header_frame.grid(row=ROOT_ROW_HEADER, column=0, sticky="ew", padx=0, pady=0)
        self.header_frame.grid_columnconfigure(1, weight=1)
        self.header_frame.grid_rowconfigure(1, weight=0)

        pad_x = SPACING["window_pad_x"]

        self.left_header_cluster = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        self.left_header_cluster.grid(row=0, column=0, sticky="w", padx=(pad_x, 8), pady=10)

        self.brand_block = ctk.CTkFrame(self.left_header_cluster, fg_color="transparent")
        self.brand_block.pack(side="left", padx=(0, 12))

        if self.logo_image is not None:
            self.logo_label = ctk.CTkLabel(
                master=self.brand_block,
                text="",
                image=self.logo_image,
                width=36,
                height=36,
            )
            self.logo_label.pack(side="left", padx=(0, 10))

        titles = ctk.CTkFrame(self.brand_block, fg_color="transparent")
        titles.pack(side="left")
        self.brand_label = ctk.CTkLabel(
            master=titles,
            text="Alpha",
            font=self._ui_font(FONTS["brand"][1], "bold"),
            text_color=COLORS["text_primary"],
        )
        self.brand_label.pack(anchor="w")
        self.brand_sub_label = ctk.CTkLabel(
            master=titles,
            text="Meeting Assistant",
            font=self._ui_font(FONTS["brand_sub"][1]),
            text_color=COLORS["text_secondary"],
        )
        self.brand_sub_label.pack(anchor="w")

        self.header_lang_frame = ctk.CTkFrame(self.left_header_cluster, fg_color="transparent")
        self.header_lang_frame.pack(side="left")

        self.source_combo_wrap, self.source_combo = self._make_language_combo(
            self.header_lang_frame, SOURCE_LANGUAGES, self.source_language, "source"
        )
        self.source_combo_wrap.pack(side="left", padx=(0, 6))

        self.swap_button = ctk.CTkButton(
            master=self.header_lang_frame,
            text="⇄",
            command=self.swap_languages,
            **self._glass_icon_button_config(),
        )
        self.swap_button.pack(side="left", padx=(0, 6))

        self.target_combo_wrap, self.target_combo = self._make_language_combo(
            self.header_lang_frame, TARGET_LANGUAGES, self.target_language, "target"
        )
        self.target_combo_wrap.pack(side="left")

        self.right_header_cluster = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        self.right_header_cluster.grid(row=0, column=2, sticky="e", padx=(8, pad_x), pady=10)

        self.summary_button = ctk.CTkButton(
            master=self.right_header_cluster,
            text=MEETING_SUMMARY_BUTTON_TEXT,
            command=self.show_meeting_summary,
            **self._glass_button_config(width=SUMMARY_BUTTON_WIDTH),
        )
        self.summary_button.pack(side="left", padx=(0, 8))

        self.always_on_top_switch = ctk.CTkSwitch(
            master=self.right_header_cluster,
            text="Always on Top",
            font=self._ui_font(FONTS["caption"][1]),
            text_color=COLORS["text_secondary"],
            fg_color=COLORS["input_bg"],
            progress_color=COLORS["accent_blue"],
            button_color=COLORS["text_primary"],
            button_hover_color="#e2e8f0",
            command=self.toggle_always_on_top,
        )
        self.always_on_top_switch.pack(side="left")

        self.listening_label = None
        self.translate_label = None
        self.header_controls = self.left_header_cluster
        self.normal_header_widgets = [
            self.source_combo,
            self.swap_button,
            self.target_combo,
            self.summary_button,
            self.always_on_top_switch,
        ]

        self.hamburger_button = ctk.CTkButton(
            master=self.right_header_cluster,
            text="≡",
            command=self.toggle_hamburger_menu,
            **self._glass_icon_button_config(font_size=22),
        )
        self.hamburger_button.pack_forget()

    # -----------------------------------------------------------------------
    # Hamburger menu (compact view)
    # -----------------------------------------------------------------------
    def create_hamburger_menu(self):
        """Create compact dropdown menu panel below the header."""
        self.menu_dropdown_frame = ctk.CTkFrame(
            master=self.header_frame,
            fg_color=COLORS["card_bg"],
            corner_radius=0,
            border_width=1,
            border_color=COLORS["border"],
        )

        menu_listening_label = ctk.CTkLabel(
            master=self.menu_dropdown_frame,
            text="Listening to:",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color=COLORS["text_secondary"],
            anchor="w",
        )
        menu_listening_label.pack(fill="x", padx=15, pady=(12, 4))

        self.source_combo_menu = ctk.CTkComboBox(
            master=self.menu_dropdown_frame,
            values=SOURCE_LANGUAGES,
            variable=self.source_language,
            width=260,
            height=32,
            font=ctk.CTkFont(family="Segoe UI", size=13),
            fg_color=COLORS["dropdown_bg"],
            border_color=COLORS["border"],
            border_width=DROPDOWN_BORDER_WIDTH,
            button_color=COLORS["accent_blue"],
            button_hover_color="#3a8eef",
            dropdown_fg_color=COLORS["dropdown_bg"],
            dropdown_hover_color="#4d4d5d",
            text_color=COLORS["text_primary"],
            corner_radius=8,
            state="readonly",
        )
        self.source_combo_menu.pack(fill="x", padx=15, pady=(0, 8))

        menu_translate_label = ctk.CTkLabel(
            master=self.menu_dropdown_frame,
            text="Translate to:",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color=COLORS["text_secondary"],
            anchor="w",
        )
        menu_translate_label.pack(fill="x", padx=15, pady=(4, 4))

        self.target_combo_menu = ctk.CTkComboBox(
            master=self.menu_dropdown_frame,
            values=TARGET_LANGUAGES,
            variable=self.target_language,
            width=260,
            height=32,
            font=ctk.CTkFont(family="Segoe UI", size=13),
            fg_color=COLORS["dropdown_bg"],
            border_color=COLORS["border"],
            border_width=DROPDOWN_BORDER_WIDTH,
            button_color=COLORS["accent_blue"],
            button_hover_color="#3a8eef",
            dropdown_fg_color=COLORS["dropdown_bg"],
            dropdown_hover_color="#4d4d5d",
            text_color=COLORS["text_primary"],
            corner_radius=8,
            state="readonly",
        )
        self.target_combo_menu.pack(fill="x", padx=15, pady=(0, 8))

        self.listen_button_menu = ctk.CTkButton(
            master=self.menu_dropdown_frame,
            text="Start Listening",
            height=FOOTER_BTN_HEIGHT,
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            fg_color=COLORS["accent_blue"],
            hover_color=COLORS["accent_blue_hover"],
            text_color=COLORS["text_primary"],
            corner_radius=RADII["button"],
            command=self.toggle_listening,
        )
        self.listen_button_menu.pack(fill="x", padx=15, pady=(4, 8))

        self.copy_translation_btn_menu = ctk.CTkButton(
            master=self.menu_dropdown_frame,
            text="Copy Translation",
            command=self.copy_translation_to_clipboard,
            **self._glass_button_config(),
        )
        self.copy_translation_btn_menu.pack(fill="x", padx=15, pady=(4, 8))

        self.always_on_top_switch_menu = ctk.CTkSwitch(
            master=self.menu_dropdown_frame,
            text="Always on Top",
            font=ctk.CTkFont(family="Segoe UI", size=13),
            text_color=COLORS["text_secondary"],
            fg_color=COLORS["dropdown_bg"],
            progress_color=COLORS["accent_blue"],
            button_color=COLORS["text_primary"],
            button_hover_color="#e0e0e0",
            command=self.toggle_always_on_top,
        )
        self.always_on_top_switch_menu.pack(anchor="w", padx=15, pady=(4, 12))

    # -----------------------------------------------------------------------
    # Responsive layout switching
    # -----------------------------------------------------------------------
    def on_window_resize(self, event):
        """React to window resize events and apply responsive layout."""
        if event.widget is not self:
            return
        self._apply_responsive_layout()

    def _get_layout_mode(self, width):
        """Return wide, medium, or compact based on window width."""
        if width >= LAYOUT_WIDE_BREAKPOINT:
            return "wide"
        if width >= LAYOUT_HAMBURGER_BREAKPOINT:
            return "medium"
        return "compact"

    def _apply_responsive_layout(self):
        """Apply header, content, footer, and status bar layout for current width."""
        try:
            width = self.winfo_width()
            if width <= 1:
                return

            mode = self._get_layout_mode(width)
            if mode != self._layout_mode:
                self._layout_mode = mode

            pad_x = (
                SPACING["window_pad_compact_x"]
                if width < LAYOUT_MEDIUM_BREAKPOINT
                else SPACING["window_pad_x"]
            )
            if hasattr(self, "content_wrapper") and self.content_wrapper is not None:
                self.content_wrapper.grid_configure(padx=pad_x)
            if hasattr(self, "status_bar_frame") and self.status_bar_frame is not None:
                self.status_bar_frame.grid_configure(padx=pad_x)
            if hasattr(self, "footer_frame") and self.footer_frame is not None:
                self.footer_frame.grid_configure(padx=0)
                for child in self.footer_frame.winfo_children():
                    if isinstance(child, ctk.CTkFrame):
                        child.grid_configure(padx=pad_x)
            if self.brand_block is not None:
                self.brand_block.pack_configure(padx=(pad_x, 8 if mode == "compact" else 12))

            self._apply_header_layout(width, mode)
            self._apply_content_layout(mode)
            self._apply_footer_layout(width)
            self._apply_status_bar_layout(width)
            self._apply_waveform_layout()
        except Exception as exc:
            print(f"Error applying responsive layout: {exc}")

    def _apply_header_layout(self, width, mode):
        """Switch header between wide, medium inline, and hamburger layouts."""
        is_hamburger = mode == "compact"

        if is_hamburger:
            if self._compact_mode is not True:
                self._compact_mode = True
                self.show_compact_layout()
        else:
            if self._compact_mode is not False:
                self._compact_mode = False
                self.show_normal_layout()
            self._pack_header_controls(mode, width)

    def _pack_header_controls(self, mode, width):
        """Layout header language controls for wide or medium layouts."""
        if self.header_lang_frame is None:
            return

        combo_width = DROPDOWN_WIDTH if mode == "wide" else 128
        for wrapper, combo in (
            (self.source_combo_wrap, self.source_combo),
            (self.target_combo_wrap, self.target_combo),
        ):
            if wrapper is not None:
                wrapper.configure(width=combo_width, height=DROPDOWN_HEIGHT)

        if mode == "wide":
            self.summary_button.configure(
                text=MEETING_SUMMARY_BUTTON_TEXT,
                width=SUMMARY_BUTTON_WIDTH,
            )
        else:
            self.summary_button.configure(
                text="Summary",
                width=108 if width < LAYOUT_MEDIUM_BREAKPOINT + 80 else SUMMARY_BUTTON_WIDTH - 20,
            )

        if width >= 560:
            self.always_on_top_switch.pack(side="left")
        else:
            self.always_on_top_switch.pack_forget()

        if self.brand_sub_label is not None:
            if width < 480:
                self.brand_sub_label.pack_forget()
            else:
                self.brand_sub_label.pack(anchor="w")

        if self.brand_label is not None and width < 460:
            self.brand_label.configure(font=self._ui_font(18, "bold"))
        elif self.brand_label is not None:
            self.brand_label.configure(font=self._ui_font(FONTS["brand"][1], "bold"))

    def show_normal_layout(self):
        """Show header controls inline; hide the hamburger menu."""
        try:
            self.hamburger_button.pack_forget()
            self._hide_hamburger_menu()
            if self.header_lang_frame is not None and not self.header_lang_frame.winfo_ismapped():
                self.header_lang_frame.pack(side="left")
            if self.summary_button is not None:
                self.summary_button.pack(side="left", padx=(0, 8))
        except Exception as exc:
            print(f"Error showing normal layout: {exc}")

    def show_compact_layout(self):
        """Show logo/title and hamburger button in compact header."""
        try:
            if self.header_lang_frame is not None:
                self.header_lang_frame.pack_forget()
            if self.summary_button is not None:
                self.summary_button.pack_forget()
            if self.always_on_top_switch is not None:
                self.always_on_top_switch.pack_forget()
            self.hamburger_button.pack(side="left", padx=(8, 0))
            self._hide_hamburger_menu()
        except Exception as exc:
            print(f"Error showing compact layout: {exc}")

    def toggle_hamburger_menu(self):
        """Toggle the compact dropdown menu below the header."""
        try:
            if self._menu_visible:
                self._hide_hamburger_menu()
            else:
                pad_x = SPACING["window_pad_x"]
                self.menu_dropdown_frame.grid(
                    row=1,
                    column=0,
                    columnspan=3,
                    sticky="ew",
                    padx=pad_x,
                    pady=(0, 8),
                )
                self._menu_visible = True
        except Exception as exc:
            print(f"Error toggling hamburger menu: {exc}")

    def _hide_hamburger_menu(self):
        """Hide the compact dropdown menu."""
        self.menu_dropdown_frame.grid_remove()
        self._menu_visible = False

    # -----------------------------------------------------------------------
    # Status bar
    # -----------------------------------------------------------------------
    def create_status_bar(self):
        """Listening status strip with LIVE indicator, waveform, and timer."""
        self.status_bar_frame = ctk.CTkFrame(
            master=self,
            height=54,
            **self._card_config(),
        )
        self.status_bar_frame.grid(
            row=ROOT_ROW_STATUS,
            column=0,
            sticky="ew",
            padx=SPACING["window_pad_x"],
            pady=(SPACING["section_gap"], 0),
        )
        self.status_bar_frame.pack_propagate(False)

        inner = ctk.CTkFrame(self.status_bar_frame, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=SPACING["card_pad"], pady=10)

        live_wrap = ctk.CTkFrame(inner, fg_color="transparent")
        live_wrap.pack(side="left")

        self.live_pill = ctk.CTkFrame(
            master=live_wrap,
            fg_color=COLORS["input_bg"],
            corner_radius=RADII["status_pill"],
            border_width=1,
            border_color=COLORS["border_soft"],
        )
        self.live_pill.pack(side="left", padx=(0, 10))

        self.live_indicator = ctk.CTkLabel(
            master=self.live_pill,
            text="○ IDLE",
            font=ctk.CTkFont(family=FONTS["status"][0], size=FONTS["status"][1], weight="bold"),
            text_color=COLORS["live_idle"],
        )
        self.live_indicator.pack(padx=10, pady=3)

        self.status_text_label = ctk.CTkLabel(
            master=live_wrap,
            text="Ready to listen",
            font=ctk.CTkFont(family=FONTS["body"][0], size=FONTS["body"][1]),
            text_color=COLORS["text_secondary"],
        )
        self.status_text_label.pack(side="left")

        self.waveform_canvas = tk.Canvas(
            inner,
            width=WAVEFORM_CANVAS_WIDTH,
            height=WAVEFORM_CANVAS_HEIGHT,
            bg=COLORS["card_bg"],
            highlightthickness=0,
            bd=0,
        )
        self.waveform_canvas.pack(side="left", padx=(12, 0))
        self._draw_waveform(idle=True)

        self._status_right_cluster = ctk.CTkFrame(inner, fg_color="transparent")
        self._status_right_cluster.pack(side="right")

        self.timer_label = ctk.CTkLabel(
            master=self._status_right_cluster,
            text="00:00",
            font=ctk.CTkFont(
                family=FONTS["timer"][0],
                size=FONTS["timer"][1],
                weight="bold",
            ),
            text_color=COLORS["text_secondary"],
        )
        self.timer_label.pack(side="right", padx=(12, 0))

        self.signal_label = ctk.CTkLabel(
            master=self._status_right_cluster,
            text="● Standby",
            font=ctk.CTkFont(family=FONTS["caption"][0], size=FONTS["caption"][1]),
            text_color=COLORS["text_muted"],
        )
        self.signal_label.pack(side="right", padx=(0, 8))

    def _get_waveform_bar_count(self):
        """14 bars in hamburger layout; 35 bars when header controls are visible."""
        if self._compact_mode is True:
            return WAVEFORM_BAR_COUNT
        return WAVEFORM_BAR_COUNT_WIDE

    def _get_waveform_canvas_width(self):
        """Match canvas width to bar count for the current layout."""
        if self._compact_mode is True:
            return WAVEFORM_CANVAS_WIDTH
        return WAVEFORM_CANVAS_WIDTH_WIDE

    def _apply_waveform_layout(self):
        """Resize waveform canvas and redraw when hamburger layout toggles."""
        if self.waveform_canvas is None:
            return
        self.waveform_canvas.configure(width=self._get_waveform_canvas_width())
        self._draw_waveform(idle=not self.is_listening)

    def _draw_waveform(self, idle=False):
        """Draw subtle animated bars on the status canvas (visual only)."""
        if self.waveform_canvas is None:
            return
        self.waveform_canvas.delete("all")
        bar_w = 5
        gap = 3
        x = 4
        max_h = WAVEFORM_CANVAS_HEIGHT - 4
        base_y = WAVEFORM_CANVAS_HEIGHT - 2

        for i in range(self._get_waveform_bar_count()):
            if idle:
                h = 3
                color = COLORS["waveform_bar_dim"]
            else:
                phase = self._waveform_phase + (i * 0.55)
                h = int(5 + (max_h - 8) * (0.35 + 0.65 * abs(math.sin(phase))))
                color = (
                    COLORS["waveform_bar"]
                    if h > max_h * 0.45
                    else COLORS["waveform_bar_mid"]
                )
            y0 = base_y - h
            self.waveform_canvas.create_rectangle(
                x, y0, x + bar_w, base_y, fill=color, outline=""
            )
            x += bar_w + gap

    def _animate_waveform(self):
        """Animate waveform only while listening; low-frequency refresh."""
        if not self.is_listening:
            self._waveform_job = None
            self._draw_waveform(idle=True)
            return
        self._waveform_phase += 0.35
        self._draw_waveform(idle=False)
        self._waveform_job = self.after(WAVEFORM_ANIMATION_MS, self._animate_waveform)

    def _animate_live_pulse(self):
        """Subtle LIVE pill pulse while listening."""
        if not self.is_listening or self.live_indicator is None:
            self._live_pulse_job = None
            return
        current = self.live_indicator.cget("text_color")
        next_color = (
            COLORS["accent_red_glow"]
            if current == COLORS["live_glow"]
            else COLORS["live_glow"]
        )
        self.live_indicator.configure(text_color=next_color)
        self._live_pulse_job = self.after(900, self._animate_live_pulse)

    def _update_timer(self):
        """Update session timer while listening."""
        if not self.is_listening or self._listen_start_time is None:
            return
        elapsed = int(time.time() - self._listen_start_time)
        mins, secs = divmod(elapsed, 60)
        hours, mins = divmod(mins, 60)
        if self.timer_label is not None:
            if hours > 0:
                self.timer_label.configure(text=f"{hours:02d}:{mins:02d}:{secs:02d}")
            else:
                self.timer_label.configure(text=f"{mins:02d}:{secs:02d}")
        self._timer_job = self.after(1000, self._update_timer)

    def _update_status_bar(self, listening=False):
        """Refresh status bar visuals for idle vs listening."""
        if self.live_indicator is None:
            return
        if listening:
            self.live_indicator.configure(text="● LIVE", text_color=COLORS["live_glow"])
            if self.live_pill is not None:
                self.live_pill.configure(
                    fg_color=COLORS["accent_red_soft"],
                    border_color=COLORS["accent_red"],
                )
            self.status_text_label.configure(
                text="Listening — capturing audio",
                text_color=COLORS["text_primary"],
            )
            self.signal_label.configure(text="● Signal OK", text_color=COLORS["accent_green"])
            self.timer_label.configure(text_color=COLORS["text_primary"])
            self._listen_start_time = time.time()
            self._waveform_phase = 0
            if self._waveform_job is not None:
                self.after_cancel(self._waveform_job)
            if self._live_pulse_job is not None:
                self.after_cancel(self._live_pulse_job)
            self._animate_waveform()
            self._animate_live_pulse()
            self._update_timer()
        else:
            self.live_indicator.configure(text="○ IDLE", text_color=COLORS["live_idle"])
            if self.live_pill is not None:
                self.live_pill.configure(
                    fg_color=COLORS["status_active_bg"],
                    border_color=COLORS["border_soft"],
                )
            self.status_text_label.configure(
                text="Ready to listen",
                text_color=COLORS["text_secondary"],
            )
            self.signal_label.configure(text="● Standby", text_color=COLORS["text_muted"])
            if self.timer_label is not None:
                self.timer_label.configure(text="00:00", text_color=COLORS["text_secondary"])
            self._listen_start_time = None
            if self._waveform_job is not None:
                self.after_cancel(self._waveform_job)
                self._waveform_job = None
            if self._timer_job is not None:
                self.after_cancel(self._timer_job)
                self._timer_job = None
            if self._live_pulse_job is not None:
                self.after_cancel(self._live_pulse_job)
                self._live_pulse_job = None
            self._draw_waveform(idle=True)

    # -----------------------------------------------------------------------
    # Right-side Meeting Summary panel
    # -----------------------------------------------------------------------
    def show_summary_panel(self):
        """Instantly show the right-side Meeting Summary column."""
        if self.right_column is None:
            return
        self.summary_panel_visible = True
        width = self.winfo_width()
        mode = self._layout_mode or self._get_layout_mode(
            width if width > 1 else LAYOUT_WIDE_BREAKPOINT
        )
        self._apply_content_layout(mode)

    def hide_summary_panel(self):
        """Instantly hide the right-side Meeting Summary column."""
        if self.right_column is None:
            return
        self.summary_panel_visible = False
        width = self.winfo_width()
        mode = self._layout_mode or self._get_layout_mode(
            width if width > 1 else LAYOUT_WIDE_BREAKPOINT
        )
        self._apply_content_layout(mode)

    def toggle_summary_panel(self):
        """Toggle right-side Meeting Summary visibility."""
        if self.summary_panel_visible:
            self.hide_summary_panel()
        else:
            self.show_summary_panel()

    def _create_summary_card(self):
        """Right column Meeting Summary card with close control."""
        self.summary_outer = ctk.CTkFrame(
            master=self.right_column,
            **self._card_config(),
        )
        self.summary_outer.grid(row=0, column=0, sticky="nsew")
        self.summary_outer.grid_rowconfigure(1, weight=1)
        self.summary_outer.grid_columnconfigure(0, weight=1)
        self.summary_card = self.summary_outer

        header = ctk.CTkFrame(self.summary_outer, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=SPACING["card_pad"], pady=(14, 8))
        header.grid_columnconfigure(0, weight=1)

        self.summary_title_label = ctk.CTkLabel(
            master=header,
            text=SUMMARY_PANEL_TITLE,
            font=self._ui_font(FONTS["section_title"][1], "bold"),
            text_color=COLORS["text_primary"],
            anchor="w",
        )
        self.summary_title_label.grid(row=0, column=0, sticky="w")

        self.summary_panel_close_btn = ctk.CTkButton(
            master=header,
            text=SUMMARY_CLOSE_ICON,
            command=self.hide_summary_panel,
            **self._glass_icon_button_config(size=SMALL_BUTTON_HEIGHT, font_size=18),
        )
        self.summary_panel_close_btn.grid(row=0, column=1, sticky="e")

        body_frame = ctk.CTkFrame(
            self.summary_outer,
            fg_color=COLORS["card_bg_soft"],
            corner_radius=RADII["button"],
            border_width=1,
            border_color=COLORS["border_soft"],
        )
        body_frame.grid(
            row=1,
            column=0,
            sticky="nsew",
            padx=SPACING["card_pad"],
            pady=(0, SPACING["card_pad"]),
        )
        body_frame.grid_rowconfigure(0, weight=1)
        body_frame.grid_columnconfigure(0, weight=1)

        text_shell = ctk.CTkFrame(body_frame, fg_color="transparent")
        text_shell.grid(row=0, column=0, sticky="nsew")

        summary_scroll = ctk.CTkScrollbar(
            master=text_shell,
            orientation="vertical",
            button_color=COLORS["border"],
            button_hover_color=COLORS["border_soft"],
            fg_color=COLORS["card_bg_soft"],
        )
        summary_scroll.pack(side="right", fill="y")

        self.summary_body_box = tk.Text(
            master=text_shell,
            bg=COLORS["card_bg_soft"],
            fg=COLORS["text_disabled"],
            font=FONTS["placeholder"],
            relief="flat",
            borderwidth=0,
            wrap="word",
            highlightthickness=0,
            padx=12,
            pady=12,
            state="disabled",
            yscrollcommand=summary_scroll.set,
        )
        self.summary_body_box.pack(side="left", fill="both", expand=True)
        summary_scroll.configure(command=self.summary_body_box.yview)

        self.summary_body_box.configure(state="normal")
        self.summary_body_box.insert("1.0", PLACEHOLDER_SUMMARY)
        self.summary_body_box.configure(state="disabled")

    # -----------------------------------------------------------------------
    # Main content
    # -----------------------------------------------------------------------
    def create_main_content(self):
        """Two-column layout: transcript + translation | Meeting Summary."""
        self.content_wrapper = ctk.CTkFrame(
            master=self,
            fg_color="transparent",
            corner_radius=0,
        )
        self.content_wrapper.grid(
            row=ROOT_ROW_CONTENT,
            column=0,
            sticky="nsew",
            padx=SPACING["window_pad_x"],
            pady=(SPACING["section_gap"], SPACING["section_gap_compact"]),
        )
        self.content_wrapper.grid_columnconfigure(0, weight=7)
        self.content_wrapper.grid_columnconfigure(1, weight=3)
        self.content_wrapper.grid_rowconfigure(0, weight=1)

        self.left_column = ctk.CTkFrame(self.content_wrapper, fg_color="transparent")
        self.left_column.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self._apply_left_column_panel_weights()
        self.left_column.grid_columnconfigure(0, weight=1)

        self.right_column = ctk.CTkFrame(self.content_wrapper, fg_color="transparent")
        self.right_column.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        self.right_column.grid_rowconfigure(0, weight=1)
        self.right_column.grid_columnconfigure(0, weight=1)

        self.paned = self.left_column

        self.initial_verse_frame = self._create_verse_section(
            master=self.left_column,
            title=SECTION_TRANSCRIPT_TITLE,
            font_size=TRANSCRIPT_BODY_FONT[1],
            body_color=COLORS["text_secondary"],
            attr_name="initial_verse_box",
            is_initial=True,
            grid_row=0,
            placeholder_text=PLACEHOLDER_TRANSCRIPT,
            placeholder_font=FONTS["placeholder"],
        )
        self.translated_verse_frame = self._create_verse_section(
            master=self.left_column,
            title=SECTION_TRANSLATION_TITLE,
            font_size=TRANSLATION_BODY_FONT[1],
            body_color=COLORS["text_primary"],
            attr_name="translated_verse_box",
            is_initial=False,
            grid_row=1,
            placeholder_text=PLACEHOLDER_TRANSLATION,
            placeholder_font=FONTS["placeholder_lg"],
        )

        self._create_summary_card()

    def _apply_content_layout(self, mode):
        """Reflow left/right columns — ~70% transcript, ~30% summary when visible."""
        if not hasattr(self, "content_wrapper") or self.content_wrapper is None:
            return
        if self.left_column is None:
            return

        show_summary = (
            self.summary_panel_visible
            and self.right_column is not None
            and mode != "compact"
        )

        if show_summary:
            self.content_wrapper.grid_columnconfigure(0, weight=7)
            self.content_wrapper.grid_columnconfigure(1, weight=3)
            self.left_column.grid(row=0, column=0, sticky="nsew", padx=(0, 8), pady=0)
            self.right_column.grid(row=0, column=1, sticky="nsew", padx=(8, 0), pady=0)
        else:
            self.content_wrapper.grid_columnconfigure(0, weight=1)
            self.content_wrapper.grid_columnconfigure(1, weight=0)
            self.left_column.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
            if self.right_column is not None:
                self.right_column.grid_remove()

    def _apply_status_bar_layout(self, width):
        """Hide non-essential status elements on very narrow windows."""
        if self.waveform_canvas is None:
            return
        compact = width < LAYOUT_STATUS_COMPACT_BREAKPOINT
        if compact:
            self.waveform_canvas.pack_forget()
            if self.status_text_label is not None:
                self.status_text_label.configure(text="Ready")
        else:
            if not self.waveform_canvas.winfo_ismapped():
                self.waveform_canvas.pack(
                    side="left",
                    padx=(16, 0),
                    before=self._status_right_cluster,
                )
            if self.status_text_label is not None and not self.is_listening:
                self.status_text_label.configure(text="Ready to listen")

        if self.signal_label is not None:
            if compact:
                self.signal_label.pack_forget()
            elif not self.signal_label.winfo_ismapped():
                self.signal_label.pack(side="right", padx=(0, 10))

    def _apply_footer_layout(self, width):
        """Reflow footer: listen on the left, actions on the right."""
        if not self._footer_buttons or self.footer_btn_row is None:
            return

        compact = width < LAYOUT_FOOTER_WRAP_BREAKPOINT
        hamburger_layout = self._compact_mode is True
        gap = (
            SPACING["footer_btn_gap_compact"]
            if width < LAYOUT_MEDIUM_BREAKPOINT
            else SPACING["footer_btn_gap"]
        )
        btn_h = FOOTER_BTN_HEIGHT_COMPACT if width < 500 else FOOTER_BTN_HEIGHT
        btn_w_primary = (
            FOOTER_BTN_WIDTH_COMPACT if width < 500 else FOOTER_BTN_WIDTH
        )
        btn_w_secondary = (
            FOOTER_BTN_WIDTH_COMPACT if width < 500 else FOOTER_BTN_WIDTH_SECONDARY
        )
        pad_x = (
            SPACING["window_pad_compact_x"]
            if width < LAYOUT_MEDIUM_BREAKPOINT
            else SPACING["window_pad_x"]
        )
        pad_y = (
            SPACING["footer_pad_y_compact"]
            if compact
            else SPACING["footer_pad_y"]
        )
        self.footer_btn_row.grid_configure(padx=pad_x, pady=pad_y)

        listen_btn, copy_btn, export_btn, clear_btn = self._footer_buttons
        for btn in self._footer_buttons:
            btn.grid_forget()
            btn.configure(height=btn_h)

        listen_btn.configure(width=btn_w_primary)
        if not hamburger_layout:
            copy_btn.configure(width=btn_w_primary if not compact else btn_w_secondary)
            export_btn.configure(width=btn_w_secondary)
            clear_btn.configure(width=btn_w_secondary)

        if hasattr(self, "left_controls_frame") and self.left_controls_frame is not None:
            for child in self.left_controls_frame.winfo_children():
                child.grid_forget()
            if hamburger_layout:
                self.left_controls_frame.grid_remove()
            else:
                self.left_controls_frame.grid(row=0, column=0, sticky="w")
        if hasattr(self, "right_actions_frame") and self.right_actions_frame is not None:
            for child in self.right_actions_frame.winfo_children():
                child.grid_forget()

        if hamburger_layout:
            self.footer_btn_row.grid_columnconfigure(0, weight=1)
            self.footer_btn_row.grid_columnconfigure(1, weight=0)
            self.footer_btn_row.grid_columnconfigure(2, weight=0)
            if hasattr(self, "right_actions_frame") and self.right_actions_frame is not None:
                self.right_actions_frame.grid(row=0, column=0, columnspan=3, sticky="ew")
                self.right_actions_frame.grid_columnconfigure(0, weight=1)
            clear_btn.grid(row=0, column=0, sticky="ew")
            return

        self.footer_btn_row.grid_columnconfigure(1, weight=1)

        if not compact:
            if not hamburger_layout:
                listen_btn.grid(row=0, column=0, sticky="w")
            copy_btn.grid(row=0, column=0, padx=(0, gap), sticky="e")
            export_btn.grid(row=0, column=1, padx=(0, gap), sticky="e")
            clear_btn.grid(row=0, column=2, sticky="e")
            if hasattr(self, "right_actions_frame") and self.right_actions_frame is not None:
                self.right_actions_frame.grid(row=0, column=2, sticky="e")
            return

        if hasattr(self, "right_actions_frame") and self.right_actions_frame is not None:
            self.right_actions_frame.grid(
                row=0 if hamburger_layout else 1,
                column=0,
                columnspan=3,
                sticky="e",
                pady=(0 if hamburger_layout else 4, 0),
            )
        if not hamburger_layout:
            listen_btn.grid(row=0, column=0, sticky="w")
        copy_btn.grid(row=0, column=0, padx=(0, gap), sticky="e")
        export_btn.grid(row=0, column=1, padx=(0, gap), sticky="e")
        clear_btn.grid(row=0, column=2, sticky="e")

    def create_footer(self):
        """Bottom toolbar with primary session controls."""
        self.footer_frame = ctk.CTkFrame(
            master=self,
            fg_color=COLORS["panel_bg"],
            corner_radius=0,
            border_width=1,
            border_color=COLORS["border"],
        )
        self.footer_frame.grid(row=ROOT_ROW_FOOTER, column=0, sticky="ew")
        self.footer_frame.grid_columnconfigure(0, weight=1)

        self.footer_btn_row = ctk.CTkFrame(self.footer_frame, fg_color="transparent")
        self.footer_btn_row.grid(
            row=0,
            column=0,
            sticky="ew",
            padx=SPACING["window_pad_x"],
            pady=SPACING["footer_pad_y"],
        )
        self.footer_btn_row.grid_columnconfigure(1, weight=1)
        self.footer_btn_row2 = None

        self.left_controls_frame = ctk.CTkFrame(self.footer_btn_row, fg_color="transparent")
        self.left_controls_frame.grid(row=0, column=0, sticky="w")

        self.right_actions_frame = ctk.CTkFrame(self.footer_btn_row, fg_color="transparent")
        self.right_actions_frame.grid(row=0, column=2, sticky="e")

        self.listen_button = ctk.CTkButton(
            master=self.left_controls_frame,
            text="Start Listening",
            command=self.toggle_listening,
            **self._primary_button_config(width=FOOTER_BTN_WIDTH),
        )

        self.footer_stop_button = None

        self.copy_translation_btn = ctk.CTkButton(
            master=self.right_actions_frame,
            text="Copy Translation",
            command=self.copy_translation_to_clipboard,
            **self._secondary_button_config(width=FOOTER_BTN_WIDTH),
        )

        self.export_btn = ctk.CTkButton(
            master=self.right_actions_frame,
            text="Export",
            command=self.export_transcript_placeholder,
            **self._secondary_button_config(width=FOOTER_BTN_WIDTH_SECONDARY),
        )

        self.clear_btn = ctk.CTkButton(
            master=self.right_actions_frame,
            text="Clear",
            command=self.clear_text,
            **self._secondary_button_config(width=FOOTER_BTN_WIDTH_SECONDARY),
        )

        self._footer_buttons = [
            self.listen_button,
            self.copy_translation_btn,
            self.export_btn,
            self.clear_btn,
        ]
        self._apply_footer_layout(self.winfo_width() if self.winfo_width() > 1 else 1180)

    def _create_toggle_button(self, master, text, width):
        """Create a compact hide/show toggle button for the Initial verse panel."""
        return ctk.CTkButton(
            master=master,
            text=text,
            command=self.toggle_initial_verse,
            **self._secondary_button_config(width=width, height=SMALL_BUTTON_HEIGHT),
        )

    def _place_toggle_button(self, parent_row, text, width):
        """Show the correct toggle button for the current transcript visibility."""
        if text == "Hide":
            self.show_initial_button.grid_remove()
            self.hide_initial_button.configure(text=text, width=width)
            self.hide_initial_button.grid(row=0, column=1, sticky="e", padx=(8, 0))
        else:
            self.hide_initial_button.grid_remove()
            self.show_initial_button.configure(text=text, width=width)
            self.show_initial_button.grid(row=0, column=1, sticky="e", padx=(8, 0))

    def check_scrollbar_visibility(self, text_widget, scrollbar):
        """Show the right scrollbar only when text content overflows the visible area."""
        try:
            text_widget.update_idletasks()
            if text_widget.yview()[0] == 0.0 and text_widget.yview()[1] == 1.0:
                scrollbar.pack_forget()
            else:
                scrollbar.pack(side="right", fill="y")
        except Exception:
            pass

    def _bind_scroll_autohide(self, text_widget, scrollbar):
        """Link scrollbar to text widget and refresh visibility on scroll/resize."""

        def yscroll_callback(first, last):
            scrollbar.set(first, last)
            self.check_scrollbar_visibility(text_widget, scrollbar)

        text_widget.configure(yscrollcommand=yscroll_callback)

        def on_configure(_event=None):
            self.check_scrollbar_visibility(text_widget, scrollbar)

        text_widget.bind("<Configure>", on_configure, add="+")
        text_widget._scroll_refresh = lambda: self.check_scrollbar_visibility(
            text_widget, scrollbar
        )

    def _create_styled_text(
        self,
        master,
        font_size,
        body_color,
        placeholder_text=None,
        placeholder_font=None,
        text_pad_y=12,
    ):
        """Create a read-only tk.Text widget with a right-side auto-hiding CTkScrollbar."""
        text_frame = ctk.CTkFrame(
            master=master,
            fg_color=COLORS["card_bg_soft"],
            corner_radius=RADII["button"],
            border_width=1,
            border_color=COLORS["border_soft"],
        )

        scrollbar = ctk.CTkScrollbar(
            master=text_frame,
            orientation="vertical",
            button_color=COLORS["border"],
            button_hover_color=COLORS["border_soft"],
            fg_color=COLORS["card_bg_soft"],
        )

        text_widget = tk.Text(
            master=text_frame,
            bg=COLORS["card_bg_soft"],
            fg=body_color,
            font=self._ui_font(font_size),
            insertbackground=COLORS["text_primary"],
            relief="flat",
            borderwidth=0,
            wrap="word",
            highlightthickness=0,
            padx=12,
            pady=text_pad_y,
            state="disabled",
        )
        text_widget.pack(side="left", fill="both", expand=True)

        scrollbar.configure(command=text_widget.yview)
        self._bind_scroll_autohide(text_widget, scrollbar)

        text_widget.tag_configure("body", foreground=body_color)
        text_widget.tag_configure("interim", foreground=COLORS["text_muted"])
        for tag_name, color in SPEAKER_COLORS.items():
            text_widget.tag_configure(tag_name, foreground=color)

        text_widget._scrollbar = scrollbar

        if placeholder_text:
            pfont = placeholder_font or FONTS["placeholder"]
            text_widget.tag_configure(
                "placeholder",
                foreground=COLORS["text_disabled"],
                font=pfont,
            )
            self._setup_text_placeholder(text_widget, placeholder_text)

        return text_frame, text_widget

    def _setup_text_placeholder(self, text_widget, placeholder_text):
        """Attach and show empty-state placeholder text."""
        text_widget._placeholder_text = placeholder_text
        text_widget._placeholder_active = False
        self._show_text_placeholder(text_widget)

    def _show_text_placeholder(self, text_widget):
        """Display placeholder copy when a text panel is empty."""
        if text_widget is None:
            return
        text_widget.configure(state="normal")
        text_widget.delete("1.0", "end")
        text_widget.insert("1.0", text_widget._placeholder_text, "placeholder")
        text_widget.configure(state="disabled")
        text_widget._placeholder_active = True
        if hasattr(text_widget, "_scrollbar"):
            self.check_scrollbar_visibility(text_widget, text_widget._scrollbar)

    def _clear_text_placeholder(self, text_widget):
        """Remove placeholder text before real content is written."""
        if text_widget is None or not getattr(text_widget, "_placeholder_active", False):
            return
        text_widget.configure(state="normal")
        current = text_widget.get("1.0", "end-1c")
        if current.strip() == text_widget._placeholder_text:
            text_widget.delete("1.0", "end")
        text_widget._placeholder_active = False

    def _is_placeholder_active(self, text_widget):
        """Return True when the panel is showing empty-state placeholder text."""
        if text_widget is None:
            return False
        if getattr(text_widget, "_placeholder_active", False):
            return True
        content = text_widget.get("1.0", "end-1c").strip()
        placeholder = getattr(text_widget, "_placeholder_text", "")
        return bool(placeholder) and content == placeholder

    def _get_text_content(self, text_widget):
        """Return visible text, ignoring placeholder copy."""
        if text_widget is None or self._is_placeholder_active(text_widget):
            return ""
        return text_widget.get("1.0", "end-1c").strip()

    def _create_verse_section(
        self,
        master,
        title,
        font_size,
        body_color,
        attr_name,
        is_initial,
        grid_row=0,
        placeholder_text=None,
        placeholder_font=None,
    ):
        """Build a labeled card with a styled tk.Text box."""
        outer = ctk.CTkFrame(master=master, **self._card_config())
        if is_initial:
            outer.grid(
                row=grid_row,
                column=0,
                sticky="nsew",
                pady=(0, SPACING["section_gap_compact"]),
            )
            title_pady = (12, 4)
            body_pady = (0, SPACING["card_pad_compact"])
            text_pad_y = 8
        else:
            outer.grid(row=grid_row, column=0, sticky="nsew", pady=(0, 0))
            title_pady = (14, 6)
            body_pady = (0, SPACING["card_pad_compact"])
            text_pad_y = 8
        outer.grid_rowconfigure(1, weight=1)
        outer.grid_columnconfigure(0, weight=1)

        title_row = ctk.CTkFrame(master=outer, fg_color="transparent")
        title_row.grid(row=0, column=0, sticky="ew", padx=SPACING["card_pad"], pady=title_pady)
        title_row.grid_columnconfigure(0, weight=1)

        title_label = ctk.CTkLabel(
            master=title_row,
            text=title,
            font=self._ui_font(FONTS["section_title"][1], "bold"),
            text_color=COLORS["text_primary"],
            anchor="w",
        )
        title_label.grid(row=0, column=0, sticky="w")

        if is_initial:
            self.initial_title_row = title_row
            self.hide_initial_button = self._create_toggle_button(title_row, "Hide", 64)
            self.hide_initial_button.grid(row=0, column=1, sticky="e", padx=(8, 0))
        else:
            self.translated_title_row = title_row
            self.translated_title_label = title_label
            self.show_initial_button = self._create_toggle_button(
                title_row, "Show Transcript", 128
            )
            self.show_initial_button.grid_remove()

        text_frame, text_widget = self._create_styled_text(
            outer,
            font_size,
            body_color,
            placeholder_text=placeholder_text,
            placeholder_font=placeholder_font,
            text_pad_y=text_pad_y,
        )
        text_frame.grid(
            row=1,
            column=0,
            sticky="nsew",
            padx=SPACING["card_pad"],
            pady=body_pady,
        )

        if not is_initial:
            outer.bind("<Double-Button-1>", lambda _e: self._restore_if_hidden())
            title_row.bind("<Double-Button-1>", lambda _e: self._restore_if_hidden())
            text_widget.bind("<Double-Button-1>", lambda _e: self._restore_if_hidden())

        setattr(self, attr_name, text_widget)
        return outer

    def _restore_if_hidden(self):
        """Restore Initial verse on double-click when in full-screen translated mode."""
        if not self._initial_verse_visible:
            self.toggle_initial_verse()

    def toggle_initial_verse(self):
        """Hide or restore the Live Transcript panel."""
        try:
            if self._initial_verse_visible:
                self.initial_verse_frame.grid_remove()
                self.left_column.grid_rowconfigure(0, weight=0)
                self.left_column.grid_rowconfigure(1, weight=1)
                self.translated_title_label.grid_remove()
                self._place_toggle_button(self.translated_title_row, "Show Transcript", 128)
                self._initial_verse_visible = False
            else:
                self.initial_verse_frame.grid()
                self._apply_left_column_panel_weights()
                self.translated_title_label.grid()
                self._place_toggle_button(self.initial_title_row, "Hide", 64)
                self._initial_verse_visible = True
        except Exception as exc:
            print(f"Error toggling initial verse: {exc}")

    def _apply_left_column_panel_weights(
        self,
        transcript_weight=TRANSCRIPT_PANEL_WEIGHT,
        translation_weight=TRANSLATION_PANEL_WEIGHT,
    ):
        """Set vertical space split between Live Transcript and Translation."""
        if self.left_column is None:
            return
        self.left_column.grid_rowconfigure(0, weight=transcript_weight)
        self.left_column.grid_rowconfigure(1, weight=translation_weight)

    def _set_initial_pane_ratio(self):
        """Set initial row weights for transcript vs translation."""
        if not self._initial_verse_visible or self.left_column is None:
            return
        try:
            self._apply_left_column_panel_weights()
            if not self._pane_initialized:
                self._pane_initialized = True
        except Exception as exc:
            print(f"Error setting initial pane sizes: {exc}")

    def _display_transcript_item(self, item):
        """Clear empty-state placeholder, then render transcript via mixin."""
        self._clear_text_placeholder(self.initial_verse_box)
        DuplicateProtectionMixin._display_transcript_item(self, item)

    def _bind_keyboard_shortcuts(self):
        """Global shortcuts that avoid interfering with text box copy/select."""
        self.bind_all("<Control-l>", self._shortcut_toggle_listening)
        self.bind_all("<Control-L>", self._shortcut_toggle_listening)
        self.bind_all("<Control-k>", self._shortcut_clear_text)
        self.bind_all("<Control-K>", self._shortcut_clear_text)
        self.bind("<Escape>", self._shortcut_escape_stop)

    def _is_text_widget_focused(self):
        """True when focus is inside a transcript/translation text panel."""
        focused = self.focus_get()
        return isinstance(focused, tk.Text)

    def _shortcut_toggle_listening(self, _event=None):
        if self._is_text_widget_focused():
            return
        self.toggle_listening()
        return "break"

    def _shortcut_clear_text(self, _event=None):
        if self._is_text_widget_focused():
            return
        self.clear_text()
        return "break"

    def _shortcut_escape_stop(self, _event=None):
        if self._is_text_widget_focused():
            return
        if self.is_listening:
            self._stop_listening()
            return "break"
        return None

    # -----------------------------------------------------------------------
    # Deepgram real-time speech-to-text
    # -----------------------------------------------------------------------
    def audio_mixer_worker(self):
        """Dual-source non-blocking mixer: WASAPI system audio + gated microphone."""
        print("[Mixer] Started with dual-source non-blocking mode")
        mix_start = time.time()
        mic_rms_history = []
        log_counts = {"mic-only": 0, "system-only": 0, "mixed": 0, "gate-skip": 0}
        max_log_per_type = 3

        def _log_mixer(kind, message):
            if log_counts.get(kind, 0) < max_log_per_type:
                print(message)
                log_counts[kind] = log_counts.get(kind, 0) + 1

        def _try_get_chunk(audio_queue):
            try:
                return audio_queue.get_nowait()
            except queue.Empty:
                return None

        def _mic_passes_gate(mic_np):
            rms = float(np.sqrt(np.mean(mic_np.astype(np.float32) ** 2)))
            now = time.time()
            mic_rms_history.append((now, rms))
            mic_rms_history[:] = [
                (t, v) for t, v in mic_rms_history if now - t <= MIC_RMS_ROLLING_WINDOW_S
            ]
            if now - mix_start < MIC_RMS_ROLLING_WINDOW_S:
                rolling_avg = MIC_NOISE_GATE_INITIAL_RMS
            elif mic_rms_history:
                rolling_avg = sum(v for _, v in mic_rms_history) / len(mic_rms_history)
            else:
                rolling_avg = MIC_NOISE_GATE_INITIAL_RMS
            gate_threshold = rolling_avg * 0.2
            return rms > gate_threshold

        while not self._stop_event.is_set():
            try:
                sys_chunk = _try_get_chunk(self.sys_audio_queue)
                mic_chunk = _try_get_chunk(self.mic_audio_queue)

                if sys_chunk is None and mic_chunk is None:
                    time.sleep(0.01)
                    continue

                sys_np_16k = None
                if sys_chunk is not None:
                    sys_np_16k = pcm_to_mono_16k_np(
                        sys_chunk, self._wasapi_channels, self._wasapi_rate
                    )
                    if sys_np_16k.size == 0:
                        sys_np_16k = None

                mic_np = None
                mic_passes = False
                if mic_chunk is not None:
                    mic_np = np.frombuffer(mic_chunk, dtype=np.int16)
                    if mic_np.size == 0:
                        mic_np = None
                    else:
                        mic_passes = _mic_passes_gate(mic_np)

                if sys_np_16k is not None and mic_np is not None and mic_passes:
                    min_len = min(len(sys_np_16k), len(mic_np))
                    if min_len > 0:
                        sys_aligned = sys_np_16k[:min_len]
                        mic_aligned = mic_np[:min_len]
                        sys_rms = float(
                            np.sqrt(np.mean(sys_aligned.astype(np.float32) ** 2))
                        )
                        mic_rms = float(
                            np.sqrt(np.mean(mic_aligned.astype(np.float32) ** 2))
                        )
                        total = sys_rms + mic_rms + 1e-6
                        sys_w = max(0.4, min(0.8, sys_rms / total))
                        mic_w = 1.0 - sys_w
                        mixed = (
                            sys_aligned.astype(np.float32) * sys_w
                            + mic_aligned.astype(np.float32) * mic_w
                        )
                        final_chunk = np.clip(mixed, -32768, 32767).astype(np.int16).tobytes()
                    else:
                        final_chunk = sys_np_16k.tobytes()
                    _log_mixer("mixed", "[Mixer] mixed chunk forwarded")
                elif sys_np_16k is not None:
                    final_chunk = sys_np_16k.tobytes()
                    _log_mixer("system-only", "[Mixer] system-only chunk forwarded")
                elif mic_np is not None and mic_passes:
                    final_chunk = mic_np.tobytes()
                    _log_mixer("mic-only", "[Mixer] mic-only chunk forwarded")
                else:
                    if mic_np is not None and not mic_passes:
                        _log_mixer("gate-skip", "[Mixer] mic below gate skipped")
                    continue

                try:
                    self._audio_q.put(final_chunk, block=True, timeout=0.5)
                except queue.Full:
                    print("[WARN] Audio queue full, dropping oldest chunk")
                    try:
                        self._audio_q.get_nowait()
                        self._audio_q.put(final_chunk, block=True, timeout=0.1)
                    except Exception:
                        pass

            except Exception as e:
                print(f"[MIXER ERROR] {e}")
                import traceback
                traceback.print_exc()

    def _set_listen_button_state(self, listening):
        """Sync Start/Stop Listening button appearance (footer + hamburger menu)."""
        if listening:
            cfg = {
                "text": "Stop Listening",
                "fg_color": COLORS["accent_red"],
                "hover_color": COLORS["accent_red_hover"],
            }
        else:
            cfg = {
                "text": "Start Listening",
                "fg_color": COLORS["accent_blue"],
                "hover_color": COLORS["accent_blue_hover"],
            }
        for btn in (self.listen_button, self.listen_button_menu):
            if btn is not None:
                btn.configure(**cfg)
        self._update_status_bar(listening=listening)

    # -----------------------------------------------------------------------
    # DeepL translation (V4)
    # -----------------------------------------------------------------------
    def _initialize_translation(self):
        """Keep translation disabled until DeepL integration is enabled in a later version."""
        self.translation_enabled = False
        self.translation_worker = None
        if self.translated_verse_box is not None:
            self.translated_verse_box._placeholder_text = PLACEHOLDER_TRANSLATION
            self._show_text_placeholder(self.translated_verse_box)

    def submit_text_for_translation(self, text, speaker=None, timestamp=None):
        """No-op until DeepL translation is enabled in a later version."""
        return

    def _on_translation_worker_result(self, result):
        """Marshal translation results onto the UI thread."""
        self.after(0, lambda: self._handle_translation_worker_result(result))

    def _handle_translation_worker_result(self, result):
        """Reserved for future DeepL UI updates; no Translation panel writes in this version."""
        return

    def record_transcript_segment(self, speaker, text, timestamp=None):
        """Store an accepted transcript segment for local summary generation."""
        try:
            self.transcript_store.add_transcript(
                speaker=speaker,
                text=text,
                timestamp=timestamp,
                source_language=self.source_language.get(),
                target_language=self.target_language.get(),
            )
        except Exception as exc:
            logger.debug("Failed to record transcript segment: %s", exc)

    def _record_translation_segment(
        self,
        original_text,
        translated_text,
        speaker=None,
        timestamp=None,
    ):
        """Attach a translation to a stored transcript segment when possible."""
        try:
            self.transcript_store.add_translation(
                original_text=original_text,
                translated_text=translated_text,
                speaker=speaker,
                timestamp=timestamp,
            )
        except Exception as exc:
            logger.debug("Failed to record translation segment: %s", exc)

    def _expand_summary_panel_if_collapsed(self):
        """Show the right-side summary panel when generating a meeting summary."""
        if not self.summary_panel_visible:
            self.show_summary_panel()

    def _set_summary_panel_text(self, text):
        """Replace summary panel body text."""
        if self.summary_body_box is None:
            return
        self.summary_body_box.configure(state="normal")
        self.summary_body_box.delete("1.0", "end")
        self.summary_body_box.insert("1.0", text or "")
        self.summary_body_box.configure(state="disabled")

    def _on_translation_worker_error(self, error_message):
        """Marshal translation errors onto the UI thread."""
        self.after(0, lambda: self._handle_translation_worker_error(error_message))

    def _handle_translation_worker_error(self, error_message):
        """Log translation errors without updating the Translation panel."""
        if self.translation_error_shown:
            return
        self.translation_error_shown = True
        logger.warning("Translation error: %s", error_message)

    def _append_translation_result(
        self,
        speaker,
        original_text,
        translated_text,
        timestamp=None,
    ):
        """Insert translated text into the translation panel (UI thread only)."""
        box = self.translated_verse_box
        if box is None:
            return

        self._clear_text_placeholder(box)
        box.configure(state="normal")

        speaker_num = speaker if speaker is not None else 1
        if self.last_translation_speaker is not None and speaker_num != self.last_translation_speaker:
            box.insert(tk.END, "\n\n")

        label = f"[Speaker {speaker_num}] "
        start_idx = box.index(tk.END)
        box.insert(tk.END, label)

        tag_name = f"speaker_{speaker_num}"
        if tag_name not in box.tag_names():
            color = EXTENDED_SPEAKER_COLORS.get(speaker_num, COLORS["text_primary"])
            box.tag_configure(tag_name, foreground=color, font=("Segoe UI", 12, "bold"))

        end_idx = box.index(tk.END)
        box.tag_add(tag_name, start_idx, end_idx)
        box.insert(tk.END, (translated_text or "").strip() + "\n", "body")
        box.configure(state="disabled")
        self.last_translation_speaker = speaker_num
        box.see(tk.END)
        if hasattr(box, "_scrollbar"):
            self.check_scrollbar_visibility(box, box._scrollbar)
        self._record_translation_segment(
            original_text,
            translated_text,
            speaker=speaker,
            timestamp=timestamp,
        )

    # -----------------------------------------------------------------------
    # Event bus (V2 — conservative integration)
    # -----------------------------------------------------------------------
    def _setup_event_subscriptions(self):
        """Wire EventBus handlers; UI updates are marshalled to the main thread."""
        self.event_bus.subscribe(EventType.APP_STATUS_CHANGED, self._on_app_status_changed)
        self.event_bus.subscribe(EventType.LISTENING_STARTED, self._on_listening_started)
        self.event_bus.subscribe(EventType.LISTENING_STOPPED, self._on_listening_stopped)
        self.event_bus.subscribe(EventType.TRANSCRIPT_RECEIVED, self._on_transcript_received)
        self.event_bus.subscribe(EventType.TRANSLATION_STARTED, self._on_translation_started)
        self.event_bus.subscribe(EventType.TRANSLATION_RECEIVED, self._on_translation_received)
        self.event_bus.subscribe(EventType.TRANSLATION_ERROR, self._on_translation_error)
        self.event_bus.subscribe(EventType.SPEAKER_DETECTED, self._on_speaker_detected)
        self.event_bus.subscribe(EventType.ERROR_OCCURRED, self._on_error_occurred)
        self.event_bus.subscribe(EventType.SUMMARY_UPDATED, self._on_summary_updated)

    def _run_on_ui_thread(self, callback):
        """Schedule a callable on the Tk main loop (safe from worker threads)."""
        try:
            self.after(0, callback)
        except Exception as exc:
            logger.error("Failed to schedule UI callback: %s", exc)

    def publish_transcript_event(
        self,
        text,
        speaker=None,
        timestamp=None,
        is_final=True,
        queue_item=None,
    ):
        """Publish transcript event and enqueue for existing process_ui_queue path."""
        if queue_item is not None:
            self.transcript_queue.put(queue_item)
        elif speaker is not None:
            self.transcript_queue.put(
                {
                    "speaker": int(speaker) if str(speaker).isdigit() else speaker,
                    "text": text,
                    "is_final": is_final,
                }
            )

        payload = TranscriptEvent(
            text=text,
            speaker=str(speaker) if speaker is not None else None,
            timestamp=timestamp,
            is_final=is_final,
        )
        self.event_bus.publish(EventType.TRANSCRIPT_RECEIVED, payload)

    def publish_translation_event(
        self,
        original_text,
        translated_text,
        source_language=None,
        target_language=None,
        speaker=None,
        timestamp=None,
        error_message=None,
    ):
        """Publish translation result event."""
        payload = TranslationEvent(
            original_text=original_text,
            translated_text=translated_text,
            source_language=source_language or self.source_language.get(),
            target_language=target_language or self.target_language.get(),
            speaker=str(speaker) if speaker is not None else None,
            timestamp=timestamp,
            error_message=error_message,
        )
        self.event_bus.publish(EventType.TRANSLATION_RECEIVED, payload)

    def publish_status_event(self, status, message=None):
        """Publish application/session status change."""
        payload = StatusEvent(status=status, message=message)
        self.event_bus.publish(EventType.APP_STATUS_CHANGED, payload)

    def publish_error_event(self, message, source=None, recoverable=True):
        """Publish backend error without blocking audio/transcription threads."""
        payload = ErrorEvent(message=message, source=source, recoverable=recoverable)
        self.event_bus.publish(EventType.ERROR_OCCURRED, payload)

    def _on_app_status_changed(self, payload: StatusEvent):
        """Update status bar message on the UI thread."""
        if not isinstance(payload, StatusEvent):
            return

        def update():
            if self.status_text_label is not None and payload.message:
                self.status_text_label.configure(text=payload.message)

        self._run_on_ui_thread(update)

    def _on_listening_started(self, payload: StatusEvent):
        logger.info("Listening started: %s", getattr(payload, "message", ""))

    def _on_listening_stopped(self, payload: StatusEvent):
        logger.info("Listening stopped: %s", getattr(payload, "message", ""))

    def _on_transcript_received(self, payload: TranscriptEvent):
        """Log transcript events; display still handled by process_ui_queue (V2)."""
        if not isinstance(payload, TranscriptEvent):
            return
        logger.debug(
            "Transcript received (speaker=%s, final=%s): %s",
            payload.speaker,
            payload.is_final,
            payload.text[:80] if payload.text else "",
        )
        # TODO V3: Move transcript display from process_ui_queue to this handler.

    def _on_translation_started(self, payload: TranslationEvent):
        if not isinstance(payload, TranslationEvent):
            return
        logger.debug(
            "Translation started (%s -> %s): %s",
            payload.source_language,
            payload.target_language,
            payload.original_text[:80] if payload.original_text else "",
        )

    def _on_translation_received(self, payload: TranslationEvent):
        """Log translation events; display handled by _append_translation_result."""
        if not isinstance(payload, TranslationEvent):
            return
        logger.debug(
            "Translation received (speaker=%s): %s",
            payload.speaker,
            payload.translated_text[:80] if payload.translated_text else "",
        )

    def _on_translation_error(self, payload: TranslationEvent):
        if not isinstance(payload, TranslationEvent):
            return
        logger.warning(
            "Translation error event: %s",
            payload.error_message or "unknown",
        )

    def _on_speaker_detected(self, payload):
        logger.debug("Speaker detected: %s", payload)

    def _on_error_occurred(self, payload: ErrorEvent):
        if not isinstance(payload, ErrorEvent):
            return
        logger.error("[%s] %s", payload.source or "app", payload.message)
        if not payload.recoverable:
            self._run_on_ui_thread(
                lambda: messagebox.showerror("Error", payload.message)
            )

    def _on_summary_updated(self, payload):
        logger.info("Summary updated event received")

    def toggle_listening(self):
        """Start or stop live transcription."""
        if self.is_listening:
            self._stop_listening()
        else:
            self._start_listening()

    def _log_startup_diagnostics(self):
        """Print safe startup diagnostics without exposing full API keys."""
        env_path = PROJECT_ROOT / ".env"
        key_status = get_deepgram_key_status()
        print("[Startup] cwd=", os.getcwd())
        print("[Startup] project_root=", PROJECT_ROOT)
        print("[Startup] .env detected=", env_path.is_file(), f"({env_path})")
        print(f"[Startup] Deepgram key status: {key_status}")
        if key_status == "configured":
            key = (DEEPGRAM_API_KEY or "").strip()
            if len(key) > 8:
                print(f"[Startup] Deepgram key mask: {key[:4]}...{key[-4:]}")
            else:
                print("[Startup] Deepgram key mask: (configured)")

    def _start_listening(self):
        """Open dual audio capture (WASAPI + gated mic) and Deepgram WebSocket."""
        self._log_startup_diagnostics()

        key_status = get_deepgram_key_status()
        if key_status == "missing":
            print(MISSING_API_KEY_MSG)
            messagebox.showerror("Deepgram API Key", MISSING_API_KEY_MSG)
            self.publish_error_event(
                MISSING_API_KEY_MSG,
                source="config",
                recoverable=True,
            )
            return
        if key_status == "placeholder":
            print(PLACEHOLDER_API_KEY_MSG)
            messagebox.showerror("Deepgram API Key", PLACEHOLDER_API_KEY_MSG)
            self.publish_error_event(
                PLACEHOLDER_API_KEY_MSG,
                source="config",
                recoverable=True,
            )
            return

        dropdown_lang = self.source_language.get()
        deepgram_lang = LANGUAGE_MAP.get(dropdown_lang, "en")
        self._listen_language = deepgram_lang
        self._print_accuracy_startup(deepgram_lang)
        print(
            f"Listening to dropdown: '{dropdown_lang}' -> Deepgram code: '{deepgram_lang}'"
        )

        try:
            self._stop_event.clear()
            self._audio_q = queue.Queue(maxsize=MAX_AUDIO_QUEUE_SIZE)
            self.sys_audio_queue = queue.Queue(maxsize=MAX_AUDIO_QUEUE_SIZE)
            self.mic_audio_queue = queue.Queue(maxsize=MAX_AUDIO_QUEUE_SIZE)
            with self._speaker_lock:
                self._last_assigned_speaker = 1
                self._last_speaker_change_time = 0.0
            self.last_transcript_hash = set()
            self._transcript_hash_order = []  # CHANGED: reset dedup order (fix 8)
            self._last_speaker_utterance = {}  # CHANGED: reset fuzzy dedup (fix 8)
            self._recent_displayed_texts = []
            self.last_speaker = None
            self.last_speaker_id = None
            self.current_speaker = None
            self.last_displayed_speaker = None
            self.last_speech_time = 0.0
            self.fallback_speaker = 1
            self._chunks_sent_count = 0
            self._transcripts_received = 0
            self._fragment_merge_meta = None
            self._health_no_transcript_hint_shown = False
            self._dg_backoff_seconds = 1.0  # CHANGED: reset reconnect backoff (fix 5)
            self._dg_replay_buffer = []  # CHANGED: clear replay buffer (fix 5)
            self._dg_awaiting_transcript_reset = False  # CHANGED: (fix 5)

            print("Starting dual audio capture (WASAPI loopback + microphone)...")
            print(
                f"[Speech] endpointing={DEEPGRAM_ENDPOINTING_MS}ms, "
                f"merge_window={TRANSCRIPT_MERGE_WINDOW_S}s"
            )
            try:
                self._start_wasapi_loopback()
            except Exception as exc:
                print(f"Audio stream error: {exc}")
                raise
            try:
                self._start_microphone_capture()
            except Exception as exc:
                print(
                    f"Microphone capture unavailable, continuing with system audio only: {exc}"
                )
            self._mix_thread = threading.Thread(
                target=self.audio_mixer_worker, daemon=True
            )
            self._mix_thread.start()
            print("Audio mix worker thread started")

            try:
                self._dg_thread = threading.Thread(
                    target=self._deepgram_worker, daemon=True
                )
                self._dg_thread.start()
                print("Deepgram worker thread started")
            except Exception as exc:
                print(f"Deepgram thread error: {exc}")
                raise

            self.is_listening = True
            self._set_listen_button_state(True)
            self._start_health_monitor()
            self.publish_status_event("listening", "Session started")
            self.event_bus.publish(
                EventType.LISTENING_STARTED,
                StatusEvent(status="listening", message="Session started"),
            )
            print(f"Listening started (language={self._listen_language})")
        except Exception as exc:
            print(f"Error starting listening: {exc}")
            self._stop_listening()

    def _stop_listening(self):
        """Close audio stream and Deepgram WebSocket."""
        try:
            self._stop_event.set()
            self.is_listening = False  # CHANGED: prevent reconnect during intentional stop (fix 5)

            self._stop_health_monitor()

            self._close_wasapi_stream()
            self._close_microphone_stream()

            if self._dg_ws is not None:
                try:
                    self._dg_ws.close()
                except Exception:
                    pass
                self._dg_ws = None

            self._audio_q = None
            self.sys_audio_queue = None
            self.mic_audio_queue = None
            self._set_listen_button_state(False)
            self.publish_status_event("idle", "Session stopped")
            self.event_bus.publish(
                EventType.LISTENING_STOPPED,
                StatusEvent(status="idle", message="Session stopped"),
            )
            print("Listening stopped")
        except Exception as exc:
            print(f"Error stopping listening: {exc}")

    def _append_initial_transcript(self, text):
        """Insert a speaker-tagged line into the Initial verse box (UI thread only)."""
        box = self.initial_verse_box
        if box is None:
            print("Warning: initial_verse_box is None, cannot insert text")
            return

        self._clear_text_placeholder(box)
        box.configure(state="normal")

        match = re.match(r"^(\[Speaker (\d+)\])(.*)$", text, re.DOTALL)
        if match:
            label = match.group(1)
            speaker_num = int(match.group(2))
            body = match.group(3)
            tag = f"speaker_{speaker_num}" if 1 <= speaker_num <= 4 else "body"
            box.insert(tk.END, label, tag)
            box.insert(tk.END, body, "body")
        else:
            box.insert(tk.END, text, "body")

        box.configure(state="disabled")
        self.check_scrollbar_visibility(box, box._scrollbar)
        box.see(tk.END)

    def _on_close(self):
        """Clean up audio/WebSocket resources before closing the window."""
        if self.is_listening:
            self._stop_listening()
        if self.translation_worker is not None:
            self.translation_worker.stop()
            self.translation_worker = None
        self.destroy()

    # -----------------------------------------------------------------------
    # Speaker-colored text helpers
    # -----------------------------------------------------------------------
    def _insert_formatted_text(self, text_widget, content):
        """Insert text with colored [Speaker N] tags into a read-only tk.Text widget."""
        self._clear_text_placeholder(text_widget)
        text_widget.configure(state="normal")
        text_widget.delete("1.0", "end")

        parts = re.split(r"(\[Speaker \d+\])", content)
        for part in parts:
            if not part:
                continue

            match = re.fullmatch(r"\[Speaker (\d+)\]", part)
            if match:
                speaker_num = int(match.group(1))
                tag = f"speaker_{speaker_num}" if 1 <= speaker_num <= 4 else "body"
                text_widget.insert("end", part, tag)
            else:
                text_widget.insert("end", part, "body")

        text_widget.configure(state="disabled")
        self.check_scrollbar_visibility(text_widget, text_widget._scrollbar)

    # -----------------------------------------------------------------------
    # Context menu
    # -----------------------------------------------------------------------
    def _create_context_menu(self):
        """Right-click context menu to clear both text areas."""
        self.context_menu = Menu(self, tearoff=0)
        self.context_menu.add_command(label="Clear All Text", command=self.clear_text)

        for box in (self.initial_verse_box, self.translated_verse_box):
            box.bind("<Button-3>", self._show_context_menu)

    def _show_context_menu(self, event):
        """Display the context menu at the cursor position."""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    # -----------------------------------------------------------------------
    # Event handlers
    # -----------------------------------------------------------------------
    def toggle_always_on_top(self):
        """Toggle window always-on-top and keep both switches in sync."""
        try:
            if self._compact_mode and self._menu_visible:
                is_on = self.always_on_top_switch_menu.get() == 1
            else:
                is_on = self.always_on_top_switch.get() == 1

            self.attributes("-topmost", is_on)

            if is_on:
                self.always_on_top_switch.select()
                self.always_on_top_switch_menu.select()
            else:
                self.always_on_top_switch.deselect()
                self.always_on_top_switch_menu.deselect()

            print(f"Always on Top: {'ON' if is_on else 'OFF'}")
        except Exception as exc:
            print(f"Error toggling always on top: {exc}")
            messagebox.showerror("Error", f"Could not update window state:\n{exc}")

    def show_meeting_summary(self):
        """Toggle right-side summary panel; refresh summary text when opening."""
        try:
            if self.summary_panel_visible:
                self.hide_summary_panel()
                return
            self.show_summary_panel()
            summary_text = self.summary_service.generate_summary_from_store(
                self.transcript_store
            )
            self._set_summary_panel_text(summary_text)
            self.event_bus.publish(EventType.SUMMARY_UPDATED, summary_text)
            print("Meeting summary updated.")
        except Exception as exc:
            logger.error("Error generating meeting summary: %s", exc)
            print(f"Error showing meeting summary: {exc}")

    def swap_languages(self):
        """Swap source and target language selections."""
        src = self._strip_language_flag(self.source_language.get())
        tgt = self._strip_language_flag(self.target_language.get())
        self.source_language.set(tgt)
        self.target_language.set(src)
        self._sync_language_combo_displays()
        self.on_language_change("both")

    def _update_translation_title(self):
        """Update translation card title from target language dropdown."""
        if self.translated_title_label is not None:
            lang = self._strip_language_flag(self.target_language.get())
            self.translated_title_label.configure(text=f"Translation ({lang})")

    def copy_translation_to_clipboard(self):
        """Copy translated verse text to the system clipboard."""
        box = self.translated_verse_box
        if box is None:
            return
        try:
            text = self._get_text_content(box)
            if not text:
                messagebox.showinfo("Copy Translation", "No translation text to copy.")
                return
            self.clipboard_clear()
            self.clipboard_append(text)
            print("Translation copied to clipboard.")
            messagebox.showinfo("Copy Translation", "Translation copied to clipboard.")
        except Exception as exc:
            print(f"Error copying translation: {exc}")
            messagebox.showerror("Copy Translation", f"Could not copy text:\n{exc}")

    def export_transcript_placeholder(self):
        """Placeholder for future export functionality."""
        messagebox.showinfo(
            "Export",
            "Export feature will be added in a later version.",
        )

    def on_language_change(self, changed="both"):
        """Handle language dropdown changes and log selections to console."""
        try:
            if changed in ("source", "both"):
                dropdown = self._strip_language_flag(self.source_language.get())
                if dropdown != self.source_language.get():
                    self.source_language.set(dropdown)
                self._listen_language = LANGUAGE_MAP.get(dropdown, "en")
                print(
                    f"Listening to dropdown: '{dropdown}' -> "
                    f"Deepgram code: '{self._listen_language}'"
                )
            if changed in ("target", "both"):
                target = self._strip_language_flag(self.target_language.get())
                if target != self.target_language.get():
                    self.target_language.set(target)
                print(f"Translate to: {target}")
                self._update_translation_title()
        except Exception as exc:
            print(f"Error updating language selection: {exc}")

    def clear_text(self):
        """Clear both the initial and translated verse text boxes."""
        try:
            self.last_transcript_hash = set()
            self._transcript_hash_order = []  # CHANGED: reset dedup order (fix 8)
            self._last_speaker_utterance = {}  # CHANGED: reset fuzzy dedup (fix 8)
            self.last_speaker = None
            self.last_speaker_id = None
            self.current_speaker = None
            self.last_displayed_speaker = None
            self.last_translation_speaker = None
            self.translation_error_shown = False
            self._recent_displayed_texts = []
            self.last_speech_time = 0.0
            self.fallback_speaker = 1
            if self.translated_verse_box is not None:
                self.translated_verse_box._placeholder_text = PLACEHOLDER_TRANSLATION
            for box in (self.initial_verse_box, self.translated_verse_box):
                box.configure(state="normal")
                box.delete("1.0", "end")
                box.configure(state="disabled")
                self._show_text_placeholder(box)
            if hasattr(self, "transcript_store") and self.transcript_store is not None:
                self.transcript_store.clear()
            self._set_summary_panel_text(PLACEHOLDER_SUMMARY)
            print("Text boxes cleared.")
        except Exception as exc:
            print(f"Error clearing text: {exc}")
            messagebox.showerror("Error", f"Could not clear text:\n{exc}")
